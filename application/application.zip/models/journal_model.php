<?php
error_reporting(E_ALL);
class Journal_model extends CI_Model{
	function _construct() {
		parent::_construct;
	}

    /// User Classes
    function insert_user()   {

        $emailaddress = $this->input->post('emailaddress');
        $password     = md5($this->input->post('password'));
        $lastname    = strtoupper($this->input->post('lastname'));
        $firstname   = strtoupper($this->input->post('firstname'));
        $middlename  = strtoupper($this->input->post('middlename'));
        $salutation  = $this->input->post('salutation');
        $gender      = $this->input->post('gender');
        $phonenumber = $this->input->post('phonenumber');
        $country     = $this->input->post('country');
        $userid     = $this->input->post('userid');

        $this->db->where('emailaddress', $emailaddress);
        $query = $this->db->get_where('users');
        if($query->num_rows > 0)
        return 2;

        $biodata = array(

        'emailaddress'  => $emailaddress,
        'password'      => $password,
        'lastname'      => $lastname,
        'firstname'     => $firstname,
        'middlename'    => $middlename,
        'salutation'    => $salutation,
        'gender'        => $gender,
        'phonenumber'   => $phonenumber,
        'country'       => $country
        ); 

        if($this->db->insert('users', $biodata)){
          return 1;
        }
        else
            return 0;
    }

    function signout() {
        $username = $this->session->userdata('username');
        //$username = $user_data['username'];
        $this->db->where('username', $username)->update('userprofile', array('useronline' => 0));
        $this->session->sess_destroy();
        return 1;
    }

    function resetuserp()
    {
        $uid =  $this->input->post('uid');
        $userid =  $this->input->post('userid');     
        $password = md5($this->input->post('newpassword'));

        $data = array(
            'password' =>  $password,
            'updaterid'=>  $userid
        );

        $this->db->where('uid', $uid);
        if($this->db->update('users', $data))
            return 1;
        else
            return 0;   
        
    }


    // Volume Mangement

    function insert_volume()   {

        $volume     = $this->input->post('volume');
        $volumeno   = $this->input->post('volumeno');
        $volumeyear = $this->input->post('volumeyear');
        $userid     = $this->input->post('userid');
        
        $volumename =  'VOLUME ' . $volume . ' NUMBER ' . $volumeno .' '. $volumeyear;

        $this->db->where('volumename', $volumename);
        $query = $this->db->get_where('volumes');
        if($query->num_rows > 0)
        return 2;

        $voldata = array(
           'volume'     => $volume,
           'volumeno'   => $volumeno,
           'volumeyear' => $volumeyear,
           'volumename'  => $volumename,
           'userid'     => $userid
        );

        if($this->db->insert('volumes', $voldata)){
            
            return 1;
        }
        else
            return 0;
    }

    function retrieveallvolume()
    {
        $query =  $this->db->query("SELECT * FROM volumes
        WHERE deletev = 0 ORDER BY dateadded DESC");
        return $query->result();
    }

    function retrievepubvolumes()
    {
        $query =  $this->db->query("SELECT * FROM volumes 
        WHERE publish = 0 AND deletev = 0 ORDER BY dateadded DESC");
        return $query->result();
    }

    function deletevolume($vid)
    {
        $this->db->where('vid', $vid)->update('volumes', array('deletev' => 1));
        return 1;   
    }


    function publishvolume($vid)
    {
        $this->db->where('vid', $vid)->update('volumes', array('publish' => 1));
        return 1;   
    }

    function unpublishvolume($vid)
    {
        $this->db->where('vid', $vid)->update('volumes', array('publish' => 0));
        return 1;   
    }

    // Editor Class
    function makeeditor($uid)
    {
        $this->db->where('uid', $uid)->update('users', array('editor' => 1));
        return 1;   
    }

    function remeditor($uid)
    {
        $this->db->where('uid', $uid)->update('users', array('editor' => 0));
        return 1;   
    }
    
    function retrieveavolume($vid)
    {
        $this->db->where('vid', $vid);
        $query = $this->db->get_where('volumes');
        return $query->row();
    }
   
    function update_volume($vid, $filename)   {

        $volumename = $this->input->post('volumename');
        $volume     = $this->input->post('volume');
        $volumeno   = $this->input->post('volumeno');
        $volumeyear = $this->input->post('volumeyear');
        $userid     = $this->input->post('userid');
        
        $volumenamenew =  'VOLUME ' . $volume . ' NUMBER ' . $volumeno .' '. $volumeyear;

        $this->db->where('volumename', $volumenamenew);
        $query = $this->db->get_where('volumes');
        if($query->num_rows > 0){
            return 2;
        }

        $voldata = array(
           'volume'      => $volume,
           'volumeno'    => $volumeno,
           'volumeyear'  => $volumeyear,
           'volumename'  => $volumenamenew,
           'image'       => $filename,
           'userid'      => $userid
        );

        $this->db->where('vid', $vid);
        if ($this->db->update('volumes', $voldata))
            return 1;
        else
            return 0;
    }


    // Back isuess Papers Class 

    function submit_paper($filename){
        $userid  = $this->input->post('userid');
        $title  = strtoupper($this->input->post('title'));
        $volume  = strtoupper($this->input->post('volume'));
        $authors  = $this->input->post('authors');
        $abstract  = $this->input->post('abstract');
    
        $papersdata = array(
          'file'     => $filename,
          'title'    => $title,
          'uid'      => $userid,
          'volume'   => $volume,
          'authors'  => $authors,
          'abstract' => $abstract
        );

        if($this->db->insert('ppapers', $papersdata)){
          return 1;
        }
        else{
            return 0;
        }
    }

    function update_paper($paid, $filename){

        $userid     = $this->input->post('userid');
        $title      = strtoupper($this->input->post('title'));
        $volume     = strtoupper($this->input->post('volume'));
        $authors    = $this->input->post('authors');
        $abstract   = $this->input->post('abstract');
        
        $papersdata = array(
          'file'     => $filename,
          'title'    => $title,
          'uid'      => $userid,
          'volume'   => $volume,
          'authors'  => $authors,
          'abstract' => $abstract
        );

       $this->db->where('paid', $paid);
        if ($this->db->update('ppapers', $papersdata))
            return 1;
        else
            return 0;
    }

    function deletepaper($paid)
    {
        $this->db->where('paid', $paid)->update('papers', array('deletep' => 1));
        return 1;   
    }

    public function readapaper($paid)
    {
        $this->db->where('paid', $paid);
        $query = $this->db->get_where('papers');
        $this->db->where('paid', $paid)->update('papers', array('read'=> 1));
        return $query->row();   
    }

    function retrievepapers()
    {
        $query =  $this->db->query("SELECT * FROM papers p 
            INNER JOIN users u ON p.uid=u.uid
            WHERE deletep = 0 ORDER BY dateadded DESC");
            return $query->result();
    }   


    function countunreadpaper()
    {
        $query =  $this->db->query("SELECT * FROM papers WHERE `read`=0");
        return $query->num_rows();
    } 

    function retrievunpapers()
    {
        $query =  $this->db->query("SELECT * FROM papers p 
            INNER JOIN users u ON p.uid=u.uid
            WHERE `read`=0 ORDER BY dateadded DESC");
            return $query->result();
    } 

    function retrieveallpapers() 
    {
        $query =  $this->db->query("SELECT * FROM ppapers p 
        INNER JOIN volumes v ON p.volume = v.vid 
        WHERE deletep = 0 ORDER BY dateadded DESC");
        return $query->result();
    } 

    function retrieveapaper($paid) 
    {
        $query =  $this->db->query("SELECT * FROM ppapers p 
        INNER JOIN volumes v ON p.volume = v.vid 
        WHERE paid = '$paid' AND deletep = 0 ORDER BY dateadded DESC");
        
        return $query->row();
    }

    function retrieve1paper($paid)
    {
        $query =  $this->db->query("SELECT * FROM papers p 
        INNER JOIN users u ON p.uid = u.uid 
        WHERE paid = '$paid'");
        return $query->row();
    }

    // SEND MESSAGES CLASSES

    function sendmessage($paid, $filename){

        $userid        = $this->input->post('userid');
        $emailaddress  = $this->input->post('emailaddress');
        $message       = $this->input->post('message');
        $uid           = $this->input->post('uid');
    
        $papersdata = array(
          'mfile'        => $filename,
          'senderid'    => $userid,
          'receiverid'  => $uid,
          'emailaddress'=> $emailaddress,
          'message'     => $message,
          'reply'       => 0,
          'paid'        => $paid
        );

        if($this->db->insert('mailmessages', $papersdata)){
            
            $message = wordwrap($message, 70);
            $subject= "JOLUD ADMIN";
            $from = "JOLUDS";
            $to = $emailaddress;
                
            $result= mail($to, $subject, $message, "From: $from");
            return 1;
        }
        else{
            return 0;
        }
    }

    function receivedmessages() 
    {
        $query =  $this->db->query("SELECT * FROM mailmessages m 
            INNER JOIN users u ON m.senderid=u.uid
            INNER JOIN papers p ON m.paid=p.paid  WHERE reply = 1 AND deletem = 0 
            ORDER BY datesent DESC");
            return $query->result();
    } 

    function sentmessages() 
    {
       $query =  $this->db->query("SELECT * FROM mailmessages m 
            INNER JOIN users u ON m.receiverid=u.uid
            INNER JOIN papers p ON m.paid=p.paid  WHERE reply = 0 AND deletem = 0 
            ORDER BY datesent DESC");
            return $query->result();
    } 

    function areceivedmess($msid) 
    {
        $query =  $this->db->query("SELECT * FROM mailmessages m 
        INNER JOIN users u ON m.senderid=u.uid 
        INNER JOIN papers p ON m.paid=p.paid
        WHERE msid = '$msid'");
        
        return $query->row();
    }

    function asentmess($msid) 
    {
        $query =  $this->db->query("SELECT * FROM mailmessages m 
        INNER JOIN users u ON m.receiverid=u.uid 
        INNER JOIN papers p ON m.paid=p.paid
        WHERE msid = '$msid'");
        
        return $query->row();
    }

    function deletemessage($msid)
    {
        $this->db->where('msid', $msid)->update('mailmessages', array('deletem' => 1));
        return 1;   
    }
   

    //Featured classes starts here

    function retrievenonefeaturedp() 
    {
        $query =  $this->db->query("SELECT * FROM ppapers p 
        INNER JOIN volumes v ON p.volume = v.vid 
        WHERE deletep = 0 AND featured = 0 ORDER BY dateadded DESC");
        return $query->result();
    } 


    function retrievefeaturedpapers() 
    {
        $query =  $this->db->query("SELECT * FROM ppapers p 
        INNER JOIN volumes v ON p.volume = v.vid 
        WHERE deletep = 0 AND featured = 1 ORDER BY dateadded DESC");
        return $query->result();
    } 

    function feature_assigned() 
    {
        $paid = $this->input->post('paid');
        $this->db->where('paid', $paid)->update('ppapers', array('featured' => 1));
        return 1;
    }

    function removefeatures($paid) 
    {
        $this->db->where('paid', $paid)->update('ppapers', array('featured' => 0));
         return 1;   
    }

    

    function retrievefilename($fileid)
    {
        $this->db->where('file', $fileid);
        $query = $this->db->get_where('papers');
        return $query->row();
    }

    function getmessfile($fileid)
    {
        $this->db->where('mfile', $fileid);
        $query = $this->db->get_where('mailmessages');
        return $query->row();
    }
    
    

    // Users Management Classes
    function retrievealusers()
    {
        $query = $this->db->get_where('users');
        return $query->result();
    }

    function retrieveauser($uid)
    {
        $this->db->where('uid', $uid);
        $query = $this->db->get_where('users');
        return $query->row();
    }

    function retrivereviews()
    {
        $query = $this->db->get_where('review');
        return $query->result();
    }
    
    function retrivenewsletter()
    {
        $query = $this->db->get_where('newslettersub');
        return $query->result();
    }


   
}