<?php
error_reporting(E_ALL);
class Home_model extends CI_Model{
	
  function _construct() {
  	parent::_construct;
  }

  function submit_signup()   {

        $emailaddress = $this->input->post('emailaddress');
        $password     = md5($this->input->post('password'));
        $lastname    = strtoupper($this->input->post('lastname'));
        $firstname   = strtoupper($this->input->post('firstname'));
        $middlename  = strtoupper($this->input->post('middlename'));
        $salutation  = $this->input->post('salutation');
        $gender      = $this->input->post('gender');
        $address     = $this->input->post('address');
        $phonenumber = $this->input->post('phonenumber');
        $country     = $this->input->post('country');
        $university     = $this->input->post('university');
        $website     = $this->input->post('website');
        $question  = $this->input->post('question');
        $answer      = strtolower($this->input->post('answer'));

         /*$author      = $this->input->post('author');
        $reviewer    = $this->input->post('reviewer');*/

        $this->db->where('emailaddress', $emailaddress);
        $query = $this->db->get_where('users');
        if($query->num_rows > 0)
        return 2;

        $biodata = array(

        'emailaddress'  => $emailaddress,
        'password'      => $password,
        'lastname'      => $lastname,
        'firstname'     => $firstname,
        'middlename'    => $middlename,
        'salutation'    => $salutation,
        'gender'        => $gender,
        'address'       => $address,
        'university'    => $university,
        'phonenumber'   => $phonenumber,
        'country'       => $country,
        'website'       => $website,
        'question'      => $question,
        'answer'        => $answer
        /*'author'        => $author,
        'reviewer'      => $reviewer*/
        ); 

        if($this->db->insert('users', $biodata)){
          return 1;
        }
        else
            return 0;
  }

  function update_profile()   {

    $uid    = strtoupper($this->input->post('uid'));
    $lastname    = strtoupper($this->input->post('lastname'));
    $firstname   = strtoupper($this->input->post('firstname'));
    $middlename  = strtoupper($this->input->post('middlename'));
    $salutation  = $this->input->post('salutation');
    $gender      = $this->input->post('gender');
    $address     = $this->input->post('address');
    $phonenumber = $this->input->post('phonenumber');
    $country     = $this->input->post('country');
    $university     = $this->input->post('university');
    $website     = $this->input->post('website');

    $biodata = array(

    'lastname'      => $lastname,
    'firstname'     => $firstname,
    'middlename'    => $middlename,
    'salutation'    => $salutation,
    'gender'        => $gender,
    'address'       => $address,
    'university'    => $university,
    'phonenumber'   => $phonenumber,
    'country'       => $country,
    'website'       => $website
    ); 

     $this->db->where('uid', $uid);
    if ($this->db->update('users', $biodata))
        return 1;
    else
        return 0;
  }

  function signout() {
        $this->session->sess_destroy();
        return 1;
    }

  public function validate() {

      $emailaddress = strtolower($this->input->post('emailaddress'));
      $password = $this->input->post('password');
      
      //return $password;
      $this->db->where('emailaddress', $emailaddress);           //Check against user table
      $query = $this->db->get_where('users');
      
      if ($query->num_rows() > 0) {
        $user_data = $query->row_array(); 
        $hashed_pass = md5($password);
        
        if($user_data['password'] != $hashed_pass)
        return 3;
        
        $this->session->sess_destroy(); //Destroy old session
        $this->session->sess_create();  //Create a fresh, brand new session
        unset($user_data['password']); //Set session data
        
        $user_data['logged_in'] = true;
        
        $this->session->set_userdata($user_data);
        $userstatus = $user_data['userstatus'];  // Change Activated flag to 1 if it is 0
        
        if ($userstatus == 'Disable' ) {
            return 2;
        }
        elseif ($userstatus == 'Enable') {
          //$this->db->where('username', $username)->update('userprofile', array('useronline' => 1));
          return 1;
        }
        
      } 
      else 
      {
        return 0;
      }   

        //return print_r($this->input->post());
  }

  public function checkemail() {

      $emailaddress = strtolower($this->input->post('emailaddress'));

      //return $password;
      $this->db->where('emailaddress', $emailaddress);           //Check against user table
      $query = $this->db->get_where('users');
      
      if ($query->num_rows() > 0) {
        $user_data = $query->row_array(); 
        
        $this->session->set_userdata($user_data);

        return 1;       
      } 
      else 
      {
        return 0;
      }   

        //return print_r($this->input->post());
  }

  public function answer() {

      $emailaddress = strtolower($this->input->post('emailaddress'));
      $answer = strtolower($this->input->post('answer'));

      //return $emailaddress;
       $query =  $this->db->query("SELECT * FROM users
      WHERE emailaddress = '$emailaddress' ");
      
      if ($query->num_rows() > 0) {
        $user_data = $query->row_array(); 
        
        $this->session->set_userdata($user_data);
          $dbanswer = $user_data['answer'];  // Change Activated flag to 1 if it is 0
        
        if($dbanswer ==  $answer) {
            return 1;
        }
        elseif($dbanswer !=  $answer) {
          
          return 2;
        }
            
      } 
      else 
      {
        return 0;
      }   

        //return print_r($this->input->post());
  }

  function newpass(){

    $uid      = strtoupper($this->input->post('uid'));
    $password = md5($this->input->post('password'));
   
    $biodata = array(
     'password'      => $password
    ); 

     $this->db->where('uid', $uid);
    if ($this->db->update('users', $biodata))
        return 1;
    else
        return 0;
  }

  
  public function retrieveditors(){ 
    $this->db->where('editor', 1);
    $query = $this->db->get_where('users');
    return $query->result();
  }

  public function record_count() {
    return $this->db->count_all("schools");
  }

  function retrievevolumes() 
  {
      $query =  $this->db->query("SELECT * FROM volumes
      WHERE deletev = 0 AND publish =1 ORDER BY dateadded DESC");
      return $query->result();
  }

  function volumed($vid)
  {
    $query =  $this->db->query("SELECT * FROM volumes WHERE vid = '$vid'");
    return $query->row();
  }

  function retrievefeatured() 
  {
      $query =  $this->db->query("SELECT * FROM ppapers
      WHERE deletep = 0 AND featured = 1 ORDER BY datecreated DESC LIMIT 2");
      return $query->result();
  }

  function retrieveapapers($paid)
  {
    $query =  $this->db->query("SELECT * FROM ppapers WHERE paid = '$paid'");
    return $query->row();
  }

  function retrieveaeditor($uid)
  {
    $query =  $this->db->query("SELECT * FROM users WHERE uid = '$uid'");
    return $query->row();
  }


  function retrievevolpapers($vid)
  {
      $query =  $this->db->query("SELECT * FROM ppapers p 
      WHERE volume = '$vid' AND deletep = 0 ORDER BY datecreated DESC");
      return $query->result();
  }

  function retrievefilename($fileid)
  {
    $this->db->where('file', $fileid);
    $query = $this->db->get_where('ppapers');
    return $query->row();
  }

  function retrievefilenamep($fileid)
  {
    $this->db->where('file', $fileid);
    $query = $this->db->get_where('papers');
    return $query->row();
  }

  

  function retrievprofile ($uid) {
    $this->db->where('uid', $uid);
    $query = $this->db->get_where('users');

    return $query->row();
  }

  function retrievmysubpapers($uid) {
    $this->db->where('uid', $uid);
    $query = $this->db->get_where('papers');

    return $query->result();
  }

  function getreceivedmess($uid) { 
    
    $query =  $this->db->query("SELECT * FROM mailmessages m 
            INNER JOIN users u ON m.receiverid=u.uid
            INNER JOIN papers p ON m.paid=p.paid 
            WHERE receiverid ='$uid' AND reply=0  ORDER BY datesent DESC ");
            return $query->result();
  }

  function getsentmess($uid) { 
    
    $query =  $this->db->query("SELECT * FROM mailmessages m 
            INNER JOIN users u ON m.senderid=u.uid
            INNER JOIN papers p ON m.paid=p.paid 
            WHERE senderid ='$uid' AND reply=1  ORDER BY datesent DESC ");
            return $query->result();
  }

  function retrieveamess($msid) 
  {
        $query =  $this->db->query("SELECT * FROM mailmessages m 
        INNER JOIN users u ON m.receiverid=u.uid 
        INNER JOIN papers p ON m.paid=p.paid
        WHERE msid = '$msid'");
        
        return $query->row();
  }

  function send_reply($uid, $filename){
      
    $senderid  = $this->input->post('senderid');
    $paid  = $this->input->post('paid');
    $emailaddress  = $this->input->post('emailaddress');
    $message  = $this->input->post('message');
    
    $papersdata = array(
      'mfile'        => $filename,
      'message'     => $message,
      'senderid'    => $uid,
      'receiverid'  => $senderid,
      'emailaddress'  => $emailaddress,
      'reply'       => 1,
      'paid'        => $paid
    );

    if($this->db->insert('mailmessages', $papersdata)){
        $message = wordwrap($message, 70);
        $subject= "JOLUD ADMIN";
        $from =  $emailaddress;
        $to = 'kennysoft03@yahoo.com';
            
        $result= mail($to, $subject, $message, "From: $from");
      return 1;
    }
    else
        return 0;

  }

    function send_message($uid, $filename){
      
    $paid  = $this->input->post('paid');
    $message  = $this->input->post('message');
    $emailaddress  = $this->input->post('emailaddress');
    
    $papersdata = array(
      'mfile'       => $filename,
      'message'     => $message,
      'emailaddress'     => $emailaddress,
      'senderid'    => $uid,
      'receiverid'    => 1,
      'reply'       => 1,
      'paid'        => $paid
    );

    if($this->db->insert('mailmessages', $papersdata)){
      return 1;
    }
    else
        return 0;

  }

  function sendmailtouser($msg,$emailaddress){
      $message = wordwrap($msg, 70);
      $subject= "You Page Visit on joluds.com";
      $from = "JOLUDS";
      $to = $emailaddress;
        
      $result= mail($to, $subject, $message, "From: $from");

      return $result;
  }

  function newletter(){
    $emailadd = $this->input->post('emailadd');  
    $new = array(
       'emailadd'   => $emailadd
    );

    $this->db->set($new); 
      if($this->db->insert('newslettersub'))
      {
          return 1;
      }
      else
          return 0;
  }

  function submit_paper($uid, $filename){

    $title  = strtoupper($this->input->post('title'));
    $authors  = $this->input->post('authors');
    $abstract  = $this->input->post('abstract');
    
    $papersdata = array(
      'file'    => $filename,
      'title' => $title,
      'uid'    => $uid,
      'authors'    => $authors,
      'abstract' => $abstract
    );

    if($this->db->insert('papers', $papersdata)){
      return 1;
    }
    else
        return 0;
  }

  public function sendsms($recipients, $message){

      $smsurl="http://api.smartsmssolutions.com/smsapi.php?";
      $username="kennysoft03";
      $userpassword="Ayomide321";
      $senderid="evrischool"; // Send ID

      $message=str_replace("<br/>", "%0A", $message);
      
      $postarray = array("username"=>$username, "password"=>$userpassword, 
        "sender"=>html_entity_decode(urldecode($senderid)), "recipient"=>$recipients, 
        "message"=>html_entity_decode(urldecode($message)));
      
      $valpost="";
      foreach ($postarray as $var=>$value) {
        $valpost .= $var."=".$value."&";
      }
      //return $valpost;
      $valpost = trim($valpost, "&");
      $ch = curl_init();
      //return print($ch);
      curl_setopt($ch, CURLOPT_URL, $smsurl);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $postarray);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $output = curl_exec ($ch);
      curl_close ($ch);
      return $output;
  }

   function submit_contact()   {

        $fullname     = $this->input->post('fullname');
        $phonenumber  = $this->input->post('phonenumber');
        $subject  = strtoupper($this->input->post('subject'));
        $emailaddress  = $this->input->post('emailaddress');
        $message      = $this->input->post('message');
       

        $biodata = array(
          'fullname'    => $fullname,
          'phonenumber' => $phonenumber,
          'subject'     => $subject,
          'emailaddress'=> $emailaddress,
          'message'     => $message
        ); 

        if($this->db->insert('contactmess', $biodata)){
          return 1;
        }
        else
            return 0;
  }

}