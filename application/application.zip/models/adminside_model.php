<?php
error_reporting(0);
class Adminside_model extends CI_Model{
	function _construct() {
		parent::_construct;
	}

    // Staff Classes
    function validate() {

        $username = strtolower($this->input->post('username'));
        $password = $this->input->post('password');

        $this->db->where('username', $username);           //Check against user table
        $query = $this->db->get_where('userprofile');

        if ($query->num_rows() > 0) {
            $user_data = $query->row_array(); 

            $hashed_pass = md5($password);

            if($user_data['password'] != $hashed_pass)
            return 3;
            
            $this->session->sess_destroy(); //Destroy old session
            
            $this->session->sess_create();  //Create a fresh, brand new session
            
            unset($user_data['password']); //Set session data
            
            $user_data['logged_in'] = true;
            $this->session->set_userdata($user_data);

            $userstatus = $user_data['userstatus'];  // Change Activated flag to 1 if it is 0
            
            if ($userstatus == 'Disable' ) 
                return 2;
            
            elseif ($userstatus == 'Enable') {
                $this->db->where('username', $username)->update('userprofile', array('useronline' => 1));
            
            return 1;
            
            }
        } 
        else 
        {
          return 0;
        }   

        //return print_r($this->input->post());
    }

    function signout() {
        $username = $this->session->userdata('username');
        //$username = $user_data['username'];
        $this->db->where('username', $username)->update('userprofile', array('useronline' => 0));
        $this->session->sess_destroy();
        return 1;
    }

    function create_staffaccount()   {

        $fullname      = strtoupper($this->input->post('fullname'));
        $username     = strtolower($this->input->post('username'));
        $department   = $this->input->post('department');
        $phonenumber  = $this->input->post('phonenumber');
        $userstatus  = $this->input->post('userstatus');
        $creatorid  = $this->input->post('creatorid');
        $strpassword  = $this->input->post('password');
        $password     = md5($this->input->post('password'));
        
        if ($department == 1)
            $status = 'SUPER ADMIN';
        elseif ($department == 2)
            $status = 'USER SUPPORT';
        elseif ($department == 4)
            $status = 'DATA INPUTER';
        elseif ($department == 5)
            $status = 'HR MANAGER';
        elseif ($department == 6)
            $status = 'CMS ASSISTANT';

        $this->db->where('username', $username);
        $query = $this->db->get_where('userprofile');
        if($query->num_rows > 0)
        return 2;

        $biodata = array(
           'fullname'   => $fullname,
           'rightlevel' => $department,
           'phone'      => $phonenumber,
           'userstatus' => $userstatus,
           'creatorid'  => $creatorid,
           'password'   => $password,
           'username'   => $username,
           'status'     => $status
        );

        if($this->db->insert('userprofile', $biodata)){
            
            return 1;
        }
        else
            return 0;
    }

    
    function update_staffaccount()   {

        $fullname    = strtoupper($this->input->post('fullname'));
        $department  = $this->input->post('department');
        $phonenumber = $this->input->post('phonenumber');
        $userstatus  = $this->input->post('userstatus');
        $updateid    = $this->input->post('userid');
        $userid     = $this->input->post('staffid');

        if ($department == 1)
            $status = 'SUPER ADMIN';
        elseif ($department == 2)
            $status = 'USER SUPPORT';
        elseif ($department == 4)
            $status = 'DATA INPUTER';
        elseif ($department == 5)
            $status = 'HR MANAGER';
        elseif ($department == 6)
            $status = 'CMS ASSISTANT';


        $staffbiodata = array(
           'fullname'    => $fullname,
           'rightlevel'  => $department,
           'phone' => $phonenumber,
           'status'      => $status,
           'userstatus'  => $userstatus,
           'updateid'   => $updateid
        );

        $this->db->where('userid', $userid);
        if ($this->db->update('userprofile', $staffbiodata))
            return 1;
        else
            return 0;
    }

    function update_newsch_name()   {

        $schoolname    = strtoupper($this->input->post('schoolname'));
        $stid  = $this->input->post('stid');

        $this->db->where('schoolname', $schoolname);           //Check against user table
        $query = $this->db->get_where('schools');

        if ($query->num_rows() > 0)
            return 2;

        $newschname = array(
           'schoolname'    => $schoolname
        );

        $this->db->where('stid', $stid);
        if ($this->db->update('schools', $newschname))
            return 1;
        else
            return 0;
    }

    function resetpassword()
    {
        $stid =  $this->input->post('stid');
        //$password = $this->input->post('newpassword');
        //echo $password ;

        $query = $this->db->get_where('schools', array('stid' => $stid));

        if ($query->num_rows() > 0)
        {
            $password = md5($this->input->post('newpassword'));
            $data = array(
                'password' => $password
            );

            $this->db->where('stid', $stid);
            if($this->db->update('schools', $data))
                return 1;
            else
                return 0;   
        }
        else
            return 0;
    }

    function retrieveastaff($userid)
    {
        $this->db->where('userid', $userid);
        $query = $this->db->get_where('userprofile');
        return $query->row();
    }

    function retrieveallstaff()
    {

        $query = $this->db->get_where('userprofile');
        return $query->result();
    }


    function retrievesubfilename($cvid)
    {
        $this->db->where('cvid', $cvid);
        $query = $this->db->get_where('careerscv');
        return $query->row();
    }

    function retrivecontactmess()
    {
        $query = $this->db->get_where('contactmess');
        return $query->result();
    }

    function retriveacontactmess($comid)
    {
        $this->db->where('comid', $comid);
        $query = $this->db->get_where('contactmess');
        return $query->row();
    }

    function retrivereviews()
    {
        $query = $this->db->get_where('review');
        return $query->result();
    }

    function deletereview($reid)
    {
        $this->db->where('reid', $reid);
        if($this->db->delete('review'))
            return 1;   
        else 
            return 0;
    }
    
    function retrivenewsletter()
    {
        $query = $this->db->get_where('newslettersub');
        return $query->result();
    }
   
}