<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
session_start();
class Login extends CI_Controller {
	
	public function index()	{
		
		$data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
		$data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
		$data['footer'] = $this->load->view('global/footer', '', TRUE);
		$data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
		$this->load->view('admin/view_login', $data);
	}

}
