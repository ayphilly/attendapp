<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(E_ALL);
session_start();
class Journal extends CI_Controller {  

    public function validate()  // Validate a User Login into the Account View
    {
        $this->load->model("journal_model");
        $result = $this->journal_model->validate();
        echo $result;
    }

    function signout()
    {
        $this->load->model('journal_model');
        $result = $this->journal_model->signout();
        redirect('login');
    }

    // Manage Papsers

    public function subpapers(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);

            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['papers'] = $this->journal_model->retrievepapers();
            $this->load->view('admin/1view_subpapers', $data);
        }
        else
            redirect('login');
    } 

    function deletepaper()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);

            $paid = $this->uri->segment(3);
            $this->load->model('journal_model');
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $result = $this->journal_model->deletepaper($paid);
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['papers'] = $this->journal_model->retrievepapers();
            $this->load->view('admin/1view_subpapers', $data);
        }
        else
            redirect('login');
        
    }

    public function addpaper(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['volumes'] = $this->journal_model->retrievepubvolumes();
            $data['papers'] = $this->journal_model->retrieveallpapers();
            $this->load->view('admin/1view_addpaper', $data);
        }
        else
            redirect('login');
    }

    public function submit_paper(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            
            $userid = $this->session->userdata('userid');
            $volume = $this->input->post('volume');
            $title = $this->input->post('title');
            $authors = $this->input->post('authors');
            $abstract = $this->input->post('abstract');
            $file1 = $_FILES['fileup']['name'];

            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model('journal_model');
        
            $filename = 'paper'.'_'.$userid.'_'.time();                         
                        
            if (!empty($file1)) {    
                $config['upload_path'] = './papers/';
                $config['allowed_types'] = 'pdf';
                $config['max_size'] = '2000';
                $config['max_width']  = '1590';
                $config['max_height']  = '900';
                $config['overwrite']  = TRUE;
                $config['file_name'] = $filename;

                $this->load->library('upload', $config);
                    
                if (empty($title) OR empty($authors) OR empty($abstract) OR empty($volume)){
                   $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -2;
                   redirect('journal/addpaper');
                }
                else
                {
                    if ( ! $this->upload->do_upload('fileup'))
                    {
                        $_SESSION['errorstatus'] = -1;
                        $_SESSION['logoerror'] = -3;
                        redirect('journal/addpaper');       
                    }
                    else
                    {   
                        $result = $this->journal_model->submit_paper($filename);
                        redirect('journal/addpaper');
                    }
                }
            }
            else
            {
               
                $_SESSION['errorstatus'] = -1;
                $_SESSION['logoerror'] = -4;
                redirect('journal/addpaper');
            }
        }
        else
            redirect('login');
    }

    public function editpaper(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $paid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['volumes'] = $this->journal_model->retrievepubvolumes();
            $data['papers'] = $this->journal_model->retrieveallpapers();
            $data['apaper'] =  $this->journal_model->retrieveapaper($paid);
            $this->load->view('admin/1view_editpaper', $data);
        }
        else
            redirect('login');
    }

    public function update_paper(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            
            $paid       = $this->input->post('paid');
            $userid     = $this->session->userdata('userid');
            $volume     = $this->input->post('volume');
            $title      = $this->input->post('title');
            $authors    = $this->input->post('authors');
            $abstract   = $this->input->post('abstract');
            $filename   = $this->input->post('file');
            $file1      = $_FILES['fileup']['name'];

            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model('journal_model');                       
                        
            if (!empty($file1)) {    
                $config['upload_path'] = './papers/';
                $config['allowed_types'] = 'pdf';
                $config['max_size'] = '2000';
                $config['max_width']  = '1590';
                $config['max_height']  = '900';
                $config['overwrite']  = TRUE;
                $config['file_name'] = $filename;

                $this->load->library('upload', $config);
                    
                if (empty($title) OR empty($authors) OR empty($abstract) OR empty($volume)){
                   $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -2;

                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();

                    $data['volumes'] = $this->journal_model->retrievepubvolumes();
                    $data['papers'] = $this->journal_model->retrieveallpapers();
                    $data['apaper'] =  $this->journal_model->retrieveapaper($paid);
                    $this->load->view('admin/1view_editpaper', $data);
                }
                else
                {
                    if ( ! $this->upload->do_upload('fileup'))
                    {
                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();

                    $data['volumes'] = $this->journal_model->retrievepubvolumes();
                    $data['papers'] = $this->journal_model->retrieveallpapers();
                    $data['apaper'] =  $this->journal_model->retrieveapaper($paid);
                    $this->load->view('admin/1view_editpaper', $data);
                        redirect('journal/1view_editpaper');       
                    }
                    else
                    {   
                        $result = $this->journal_model->update_paper($paid, $filename);
                        
                        $data['unrpapers'] = $this->journal_model->retrievunpapers();
                        $data['unreadp'] = $this->journal_model->countunreadpaper();

                        $data['volumes'] = $this->journal_model->retrievepubvolumes();
                        $data['papers'] = $this->journal_model->retrieveallpapers();
                        $data['apaper'] =  $this->journal_model->retrieveapaper($paid);
                        $this->load->view('admin/1view_editpaper', $data);
                    }
                }
            }
            else
            {
               
                $_SESSION['errorstatus'] = -1;
                $_SESSION['logoerror'] = -4;
                $data['unrpapers'] = $this->journal_model->retrievunpapers();
                $data['unreadp'] = $this->journal_model->countunreadpaper();

                $data['volumes'] = $this->journal_model->retrievepubvolumes();
                $data['papers'] = $this->journal_model->retrieveallpapers();
                $data['apaper'] =  $this->journal_model->retrieveapaper($paid);
                $this->load->view('admin/1view_editpaper', $data);
            }
        }
        else
            redirect('login');
    }

    function readpaper()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);

            $paid = $this->uri->segment(3);
            $this->load->model('journal_model');
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            
            $data['apaper'] = $this->journal_model->readapaper($paid);
            $data['papers'] = $this->journal_model->retrievepapers();

            $this->load->view('admin/1view_apapers', $data);
        }
        else
            redirect('login');
        
    }
    // SET Featured Paper
    public function addfeatured(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['nonfeatured'] = $this->journal_model->retrievenonefeaturedp();
            $data['featured'] = $this->journal_model->retrievefeaturedpapers();
            $this->load->view('admin/1view_featuredp', $data);
        }
        else
            redirect('login');
    }

    public function removefeatured(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("journal_model");
            $paid = $this->uri->segment(3);
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $result =  $this->journal_model->removefeatures($paid);
            $data['nonfeatured'] = $this->journal_model->retrievenonefeaturedp();
            $data['featured'] = $this->journal_model->retrievefeaturedpapers();
            $this->load->view('admin/1view_featuredp', $data);
        }
        else
            redirect('login');
    }

    public function submit_featured(){
        
        $this->load->model('journal_model');
        $result = $this->journal_model->feature_assigned();
        echo $result;  
    }

    // Create and Manage Journal Volume
    public function volume(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);

            $this->load->model("journal_model");
            $data['vol'] = $this->journal_model->retrieveallvolume();
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $this->load->view('admin/1view_volume', $data);
        }
        else
            redirect('login');
    } 

    public function submit_volume(){  
        $this->load->model('journal_model');
        $result = $this->journal_model->insert_volume();
        echo $result;
    }
     

    public function editvolume(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $vid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['vol'] = $this->journal_model->retrieveallvolume();
            $data['avol'] =  $this->journal_model->retrieveavolume($vid);
            $this->load->view('admin/1view_editvolume', $data);
        }
        else
            redirect('login');
    }

    public function update_volume(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $volumename = $this->input->post('volumename');
            $vid = $this->input->post('vid');
            $filename = 'Volume_'.$vid.'_Cover';
            $file1 = $_FILES['volimage']['name'];
            
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);
            
            if (!empty($file1))     {    
                $config['upload_path'] = './papers/';
                $config['allowed_types'] = 'jpg|jpeg|JPEG|JPG';
                $config['max_size'] = '2000';
                $config['max_width']  = '1024';
                $config['max_height']  = '968';
                $config['overwrite']  = TRUE;
                $config['file_name'] = $filename;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('volimage'))
                {
                    $_SESSION['errorstatus']= -1;
                    $_SESSION['logoerror']= -3;

                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();
                    $data['vol'] = $this->journal_model->retrieveallvolume();
                    $data['avol'] =  $this->journal_model->retrieveavolume($vid);
                    $this->load->view('admin/1view_editvolume', $data);
                }
                else
                {   
                    $this->load->model('journal_model');
                    $result = $this->journal_model->update_volume($vid, $filename);
     
                    if($result == 1){
                        $_SESSION['errorstatus']= 1;
                        $data['unrpapers'] = $this->journal_model->retrievunpapers();
                        $data['unreadp'] = $this->journal_model->countunreadpaper();
                        $data['vol'] = $this->journal_model->retrieveallvolume();
                        $data['avol'] =  $this->journal_model->retrieveavolume($vid);
                        $this->load->view('admin/1view_editvolume', $data);
                   }
                    elseif($result == 2){
                        $_SESSION['errorstatus']= -1;
                        $_SESSION['logoerror']= -4;
                        $data['unrpapers'] = $this->journal_model->retrievunpapers();
                        $data['unreadp'] = $this->journal_model->countunreadpaper();
                        $data['vol'] = $this->journal_model->retrieveallvolume();
                        $data['avol'] =  $this->journal_model->retrieveavolume($vid);
                        $this->load->view('admin/1view_editvolume', $data);
                    }
                }
            }
            else
            {
                $this->load->model('journal_model');
                $result = $this->journal_model->update_volume($vid, $filename);

                $_SESSION['errorstatus']= -1;
                $_SESSION['logoerror']= -2;

                $data['unrpapers'] = $this->journal_model->retrievunpapers();
                $data['unreadp'] = $this->journal_model->countunreadpaper();
                $data['vol'] = $this->journal_model->retrieveallvolume();
                $data['avol'] =  $this->journal_model->retrieveavolume($vid);
                $this->load->view('admin/1view_editvolume', $data);
            }
        }
        else
            redirect('login');
    }
    
    
    function deletevolume()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $vid = $this->uri->segment(3);
            $this->load->model('journal_model');
            $result = $this->journal_model->deletevolume($vid);
            $data['vol'] = $this->journal_model->retrieveallvolume();
            $this->load->view('admin/1view_volume', $data);
        }
        else
            redirect('login');   
    }

    function pvolume()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $vid = $this->uri->segment(3);
            $this->load->model('journal_model');
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $result = $this->journal_model->publishvolume($vid);
            $data['vol'] = $this->journal_model->retrieveallvolume();
            $this->load->view('admin/1view_volume', $data);
        }
        else
            redirect('login');   
    }

    function unpvolume()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $vid = $this->uri->segment(3);
            $this->load->model('journal_model');
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $result = $this->journal_model->unpublishvolume($vid);
            $data['vol'] = $this->journal_model->retrieveallvolume();
            $this->load->view('admin/1view_volume', $data);
        }
        else
            redirect('login');
        
    }

    // Manage User as Editor

    public function users(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);

            $this->load->model("journal_model");
            $data['users'] = $this->journal_model->retrievealusers();
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $this->load->view('admin/1view_users', $data);
        }
        else
            redirect('login');
    }  

    public function submit_user(){
        
        $this->load->model('journal_model');
        $result = $this->journal_model->insert_user();
        echo $result;
    }

    public function editusers(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $uid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['users'] = $this->journal_model->retrievealusers();
            $data['auser'] =  $this->journal_model->retrieveauser($uid);
            $this->load->view('admin/1view_users', $data);
        }
        else
            redirect('login');
    }

    public function resetpass(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $uid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['users'] = $this->journal_model->retrievealusers();
            $data['auser'] =  $this->journal_model->retrieveauser($uid);
            $this->load->view('admin/view_changeuserpass', $data);
        }
        else
            redirect('login');
    }

    function resetuserp()
    {
        $this->load->model('journal_model');
        $result = $this->journal_model->resetuserp();
        echo $result ;
    }

    public function makeeditor(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $uid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $result =  $this->journal_model->makeeditor($uid);
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['users'] = $this->journal_model->retrievealusers();
            $this->load->view('admin/1view_users', $data);
        }
        else
            redirect('login');
    }

    public function remeditor(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $uid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $result =  $this->journal_model->remeditor($uid);
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['users'] = $this->journal_model->retrievealusers();
            $this->load->view('admin/1view_users', $data);
        }
        else
            redirect('login');
    }
    
    // Create and Manage Papers



    // Send User a Mail about HIS/HER Submmitted Paper

    public function mail(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $paid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['apaper'] =  $this->journal_model->retrieve1paper($paid);
            $this->load->view('admin/1view_mailuser', $data);
        }
        else
            redirect('login');
    }

    public function send_mail(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $paid  = $this->input->post('paid');
            $message  = $this->input->post('message');
            $file1 = $_FILES['fileup']['name'];

            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $filename = 'mail'.'_'.$paid.'_'.time(); 
            $this->load->model('journal_model');                       
                        
            if (!empty($file1)) {    
                $config['upload_path'] = './papers/';
                $config['allowed_types'] = 'docx';
                $config['max_size'] = '2000';
                $config['max_width']  = '1590';
                $config['max_height']  = '900';
                $config['overwrite']  = TRUE;
                $config['file_name'] = $filename;

                $this->load->library('upload', $config);
                    
                if (empty($message)){
                    $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -2;

                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();

                    $data['apaper'] =  $this->journal_model->retrieve1paper($paid);
                    $this->load->view('admin/1view_mailuser', $data);
                }
                else
                {
                    if ( ! $this->upload->do_upload('fileup'))
                    {
                    $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -3;
                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();

                    $data['apaper'] =  $this->journal_model->retrieve1paper($paid);
                    $this->load->view('admin/1view_mailuser', $data);
                    }
                    else
                    {   
                        $result = $this->journal_model->sendmessage($paid, $filename);
                        redirect('journal/messages');
                    }
                }
            }
            else
            {
                if (empty($message)){
                    $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -2;

                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();

                    $data['apaper'] =  $this->journal_model->retrieve1paper($paid);
                    $this->load->view('admin/1view_mailuser', $data);
                }
                else{
                    $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -4;
                    $data['unrpapers'] = $this->journal_model->retrievunpapers();
                    $data['unreadp'] = $this->journal_model->countunreadpaper();

                    $result = $this->journal_model->sendmessage($paid, $filename);
                    redirect('journal/messages');
                }
            }
        }
        else
            redirect('login');
    }

    public function messages(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['rmess'] = $this->journal_model->receivedmessages();
            $data['smess'] = $this->journal_model->sentmessages();
            $this->load->view('admin/1view_messages', $data);
        }
        else
            redirect('login');
    }

    public function deletem(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $msid = $this->uri->segment(3);
            $result = $this->journal_model->deletemessage($msid);
            $data['rmess'] = $this->journal_model->receivedmessages();
            $data['smess'] = $this->journal_model->sentmessages();
            $this->load->view('admin/1view_messages', $data);
        }
        else
            redirect('login');
    }

    public function readarmessage(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $msid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['rmess'] = $this->journal_model->receivedmessages();
            $data['smess'] = $this->journal_model->sentmessages();
            $data['message'] = $this->journal_model->areceivedmess($msid);
            $this->load->view('admin/1view_amessages', $data);
        }
        else
            redirect('login');
    }

    public function readasmessage(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $msid = $this->uri->segment(3);
            $this->load->model("journal_model");
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $data['unreadp'] = $this->journal_model->countunreadpaper();

            $data['rmess'] = $this->journal_model->receivedmessages();
            $data['smess'] = $this->journal_model->sentmessages();
            $data['message'] = $this->journal_model->asentmess($msid);
            $this->load->view('admin/1view_amessages', $data);
        }
        else
            redirect('login');
    }
   
   //Newsletter Management

    public function viewnewletter(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("journal_model");
            $data['news'] = $this->journal_model->retrivenewsletter();
            $this->load->view('admin/view_newsletter', $data);
        }
        else
            redirect('login');
    }

    public function downloadpdf()
    {
        
        $fileid = $this->uri->segment(3);
        
        $this->load->model("journal_model");
        $result = $this->journal_model->retrievefilename($fileid);
        $this->load->helper('download');
        
        $filepath = site_url("/papers/") . '/' . $fileid . '.docx';
        $data = file_get_contents($filepath); // Read the file's contents

        $name = $result->title . '.' . 'docx';
        force_download($name, $data); 
    }

    public function getmessfile()
    {
        
        $fileid = $this->uri->segment(3);
        
        $this->load->model("journal_model");
        $result = $this->journal_model->getmessfile($fileid);
        $this->load->helper('download');
        
        $filepath = site_url("/papers/") . '/' . $fileid . '.docx';
        $data = file_get_contents($filepath); // Read the file's contents

        $name = $result->emailaddress . '.' . 'docx';
        force_download($name, $data); 
    }

}