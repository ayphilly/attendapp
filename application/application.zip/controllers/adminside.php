<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
session_start();
class Adminside extends CI_Controller {
    
    public function index(){
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $data['allstaff']=  $this->db->count_all('userprofile');
            $data['allppapers']=  $this->db->count_all('ppapers');
            $data['allvolumes']=  $this->db->count_all('volumes');
            $data['allsubpapers']=  $this->db->count_all('papers');
           
            $this->load->model("journal_model");
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['unrpapers'] = $this->journal_model->retrievunpapers();
            $this->load->view('admin/dashboard', $data);
        }
        else
            redirect('login');
    }  

    // Account Settings
    public function dashboard(){
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $data['allstaff']=  $this->db->count_all('userprofile');
            $data['allppapers']=  $this->db->count_all('ppapers');
            $data['allvolumes']=  $this->db->count_all('volumes');
            $data['allsubpapers']=  $this->db->count_all('papers');


           $this->load->model("journal_model");
            $data['unreadp'] = $this->journal_model->countunreadpaper();
            $data['unrpapers'] = $this->journal_model->retrievunpapers();

            $this->load->view('admin/dashboard', $data);
        }
        else
            redirect('login');
    }   

    public function validate()  // Validate a User Login into the Account View
    {
        $this->load->model("adminside_model");
        $result = $this->adminside_model->validate();
        echo $result;
    }

    function signout()
    {
        $this->load->model('adminside_model');
        $result = $this->adminside_model->signout();
        redirect('login');
    }

    // Create and Manage New Staff
    public function staff(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("adminside_model");
            $data['staff'] = $this->adminside_model->retrieveallstaff();
            $this->load->view('admin/view_staff', $data);
        }
        else
            redirect('login');
    }  

    public function editstaff(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $userid = $this->uri->segment(3);
            $this->load->model("adminside_model");
            $data['staff'] = $this->adminside_model->retrieveallstaff();
            $data['staffid'] =  $this->adminside_model->retrieveastaff($userid);
            $this->load->view('admin/view_editstaff', $data);
        }
        else
            redirect('login');
    }

    public function myprofile(){
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {    

            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $stid = $this->session->userdata('stid');
            $this->load->model('adminside_model');
            $data['studentrecord'] = $this->adminside_model->profilepreview($stid);
            $this->load->view('admin/view_staffprev', $data);
        }
        else
            redirect('login');
    }

    public function upload_staffimage(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $stid = $this->input->post('stid');
            $filename = 'staff'.'_'.$stid;
            $file1 = $_FILES['passport']['name'];
            
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);
            
            if (!empty($file1))     {    
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|jpeg|JPEG|JPG|png';
                $config['max_size'] = '300';
                $config['max_width']  = '1024';
                $config['max_height']  = '768';
                $config['overwrite']  = TRUE;
                $config['file_name'] = $filename;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('passport'))
                {
                   $_SESSION['transstatus']=1;
                   redirect('adminside/dashboard');
                }
                else
                {   
                    $this->load->model('adminside_model');
                    $result = $this->adminside_model->upload_staffimage($stid, $filename);
     
                    if($result == 1)
                        redirect('adminside/preview');
                    else
                        redirect('adminside/dashboard');
                }
            }
            else
            {
                $_SESSION['transstatus'] = 2;
                redirect('adminside/dashboard');
            }
        }
        else
            redirect('login');
    }
    
    public function submit_staff(){
        
        $this->load->model('adminside_model');
        $result = $this->adminside_model->create_staffaccount();
        echo $result;
    }

    public function update_staff(){
        
        $this->load->model('adminside_model');
        $result = $this->adminside_model->update_staffaccount();
        echo $result;
    }

    function deletestaff()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $userid = $this->uri->segment(3);
            $this->load->model('adminside_model');
            $result = $this->adminside_model->deletestaff($userid);
            if ($result==1) {
                $data['staff'] = $this->adminside_model->retrievestaff();
                $this->load->view('admin/view_staff', $data);
            }
            else
                $this->load->view('admin/view_staff', $data);
        }
        else
            redirect('login');
        
    }

    function resetpassword()
    {
        $this->load->model('adminside_model');
        $result = $this->adminside_model->resetpassword();
        echo $result ;
    }


    function changepass()
    {
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->view('admin/view_changepass', $data);
        }
        else
            redirect('login');
        
    }


    //Email Management 
    public function contactmessages(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("adminside_model");
            $data['message'] = $this->adminside_model->retrivecontactmess();
            $this->load->view('admin/view_contactmessage', $data);
        }
        else
            redirect('login');
    }

    public function readconmess(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $comid = $this->uri->segment(3);
            $this->load->model("adminside_model");
            $data['amessage'] = $this->adminside_model->retriveacontactmess($comid); 
            $data['message'] = $this->adminside_model->retrivecontactmess();
            $this->load->view('admin/1view_acontmess', $data);
        }
        else
            redirect('login');
    }


    //Newsletter Management

        public function viewnewletter(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/css_dependencies', '', TRUE);
            $data['js'] = $this->load->view('global/js_dependencies', '', TRUE);
            $data['sidebar'] = $this->load->view('global/sidebarmenu', '', TRUE);
            $data['footer'] = $this->load->view('global/footer', '', TRUE);
            $data['dialogs'] = $this->load->view('frs_dialogs.php', '', TRUE);
            $data['header'] = $this->load->view('global/header.php', '', TRUE);

            $this->load->model("adminside_model");
            $data['news'] = $this->adminside_model->retrivenewsletter();
            $this->load->view('admin/view_newsletter', $data);
        }
        else
            redirect('login');
    }

}