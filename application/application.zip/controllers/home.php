<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    error_reporting(E_ALL);
    session_start();
    class Home extends CI_Controller {

    public function __construct() {
        parent:: __construct();
        $this->load->helper("url");
    }

    // Create and Manage schools
    public function index() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);
        
        $this->load->model('home_model');
        $data['editor'] = $this->home_model->retrieveditors();
        $data['volumes'] = $this->home_model->retrievevolumes();
        $data['featured'] = $this->home_model->retrievefeatured();

        $this->load->view('public/home', $data);
    }

    public function about() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);
        
        $this->load->model('home_model');
        $data['editor'] = $this->home_model->retrieveditors();
        $data['volumes'] = $this->home_model->retrievevolumes();

        $this->load->view('public/about', $data);
    }

    public function publications() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);
        
        $this->load->model('home_model');
        $data['editor'] = $this->home_model->retrieveditors();
        $data['volumes'] = $this->home_model->retrievevolumes();

        $this->load->view('public/publications', $data);
    }

    public function instruction() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);
        
        $this->load->model('home_model');
        $data['editor'] = $this->home_model->retrieveditors();
        $data['volumes'] = $this->home_model->retrievevolumes();

        $this->load->view('public/instruction', $data);
    }

    public function editors() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);
        
        $this->load->model('home_model');
        $data['editor'] = $this->home_model->retrieveditors();
        $data['volumes'] = $this->home_model->retrievevolumes();

        $this->load->view('public/editors', $data);
    }

    public function contact() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);
        
        $this->load->model('home_model');
        $letters = 'abcde123456789';
        $data['capcha']   = substr(str_shuffle($letters), 0, 4);
        $data['editor'] = $this->home_model->retrieveditors();
        $data['volumes'] = $this->home_model->retrievevolumes();

        $this->load->view('public/contact', $data);
    }

    public function aneditor() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $uid = $this->uri->segment(3);
        $this->load->model('home_model');

        $data['volumes'] = $this->home_model->retrievevolumes();
        $data['editor'] = $this->home_model->retrieveaeditor($uid);
        $this->load->view('public/aneditor', $data);
    }

    public function submit_contact(){ 
        $this->load->model('home_model');
        $result = $this->home_model->submit_contact();
        //echo $result;
        echo $result;
    }
    
    public function register() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $letters = 'abcde123456789';
        $data['capcha']   = substr(str_shuffle($letters), 0, 4);
        $this->load->view('public/register', $data);
    }

    public function submit_signup(){ 
        $this->load->model('home_model');
        $result = $this->home_model->submit_signup();
        echo $result;
        //redirect('home/signup'); 
    } 

    public function login() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $this->load->view('public/login', $data);
    }

    public function submit_login(){ 
        $this->load->model('home_model');
        $result = $this->home_model->validate();
        //print_r($result);
        echo $result;
    }

    function signout()
    {
        $this->load->model('home_model');
        $result = $this->home_model->signout();
        redirect('home/login');
    }



    public function getpass() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $this->load->view('public/getpassword', $data);
    }

    public function submit_resetpass(){ 
        $this->load->model('home_model');
        $result = $this->home_model->checkemail();
        //print_r($result);
        echo $result;
    }

    public function question() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            $uid = $this->session->userdata('uid');
            $this->load->view('public/question', $data);
        }
        else
            redirect('home/login');
    }

    public function submit_answer(){ 
        $this->load->model('home_model');
        $result = $this->home_model->answer();
        //print_r($result);
        echo $result;
    }

    public function newpass() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            $uid = $this->session->userdata('uid');
            $this->load->view('public/newpass', $data);
        }
        else
            redirect('home/login');
    }

    public function submit_newpass(){ 
        $this->load->model('home_model');
        $result = $this->home_model->newpass();
        //print_r($result);
        echo $result;
    }

       
    public function volume() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $vid = $this->uri->segment(3);
        $this->load->model('home_model');

        $data['volumes'] = $this->home_model->retrievevolumes();
        $data['volpapers'] = $this->home_model->retrievevolpapers($vid);
        $data['volume'] = $this->home_model->volumed($vid);
        $this->load->view('public/volume', $data);
    }

    public function paperdetails() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $paid = $this->uri->segment(3);
        $this->load->model('home_model');

        $data['volumes'] = $this->home_model->retrievevolumes();
        $data['apaper'] = $this->home_model->retrieveapapers($paid);
        $this->load->view('public/apaper', $data);
    }

    public function newletter(){ 
        $this->load->model('home_model');
        $result = $this->home_model->newletter();
        
        redirect('home');
    }

    public function error() {
        $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
        $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
        $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
        $data['menu'] = $this->load->view('global/public_menu', '', TRUE);

        $this->load->view('public/error', $data);
    }


    // User Admin classess
    
    public function profile() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            $uid = $this->session->userdata('uid');
            $data['profile'] = $this->home_model->retrievprofile($uid);
            $this->load->view('public/profile', $data);
        }
        else
            redirect('home/login');
    }

    public function editprofile() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            $uid = $this->session->userdata('uid');
            $data['profile'] = $this->home_model->retrievprofile($uid);
            $this->load->view('public/profileedit', $data);
        }
        else
            redirect('home/login');
    }

    public function update_profile(){ 
        $this->load->model('home_model');
        $result = $this->home_model->update_profile();
        echo $result;
    } 

    public function mysubpapers() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            $uid = $this->session->userdata('uid');
            $data['mypapers'] = $this->home_model->retrievmysubpapers($uid);
            $this->load->view('public/mysubpapers', $data);
        }
        else
            redirect('home/login');
    }

    public function subpapers() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->view('public/subpapers', $data);
        }
        else
            redirect('home/login');
    }


    public function messages() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            $uid = $this->session->userdata('uid');
            $data['rmess'] = $this->home_model->getreceivedmess($uid);
            $data['smess'] = $this->home_model->getsentmess($uid);
            $this->load->view('public/messages', $data);
        }
        else
            redirect('home/login');
    }

    public function replymail() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $msid = $this->uri->segment(3);
            $this->load->model('home_model');
            $data['message'] = $this->home_model->retrieveamess($msid);
            $this->load->view('public/replymail', $data);
        }
        else
            redirect('home/login');
    }

    public function send_reply(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $uid = $this->session->userdata('uid');
            $paid = $this->input->post('paid');
            $msid = $this->input->post('msid');
            $message = $this->input->post('message');
            $file1 = $_FILES['fileup']['name'];

            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            
                $filename = 'reply'.'_'.$paid.'_'.time();                         
                            
                if (!empty($file1)) {    
                    $config['upload_path'] = './papers/';
                    $config['allowed_types'] = 'docx';
                    $config['max_size'] = '2000';
                    $config['max_width']  = '1590';
                    $config['max_height']  = '900';
                    $config['overwrite']  = TRUE;
                    $config['file_name'] = $filename;

                    $this->load->library('upload', $config);
                        
                    if (empty($message)){
                        $_SESSION['errorstatus'] = -1;
                        $_SESSION['logoerror'] = -2;
                        $data['message'] = $this->home_model->retrieveamess($msid);
                        $this->load->view('public/replymail', $data);
                    }
                    else
                    {
                        if ( ! $this->upload->do_upload('fileup'))
                        {
                            $_SESSION['errorstatus'] = -1;
                            $_SESSION['logoerror'] = -3; 

                            $data['message'] = $this->home_model->retrieveamess($msid);
                            $this->load->view('public/replymail', $data);      
                        }
                        else
                        {   
                            $result = $this->home_model->send_reply($uid, $filename);
                            $data['rmess'] = $this->home_model->getreceivedmess($uid);
                            $data['smess'] = $this->home_model->getsentmess($uid);
                            $this->load->view('public/messages', $data);
                        }
                    }
                }
                else
                {
                    if (empty($message)){
                        $_SESSION['errorstatus'] = -1;
                        $_SESSION['logoerror'] = -2;
                        $data['message'] = $this->home_model->retrieveamess($msid);
                        $this->load->view('public/replymail', $data);
                    }
                    else
                    {
                        $filename = 0;
                        $result = $this->home_model->send_reply($uid, $filename);
                        $data['rmess'] = $this->home_model->getreceivedmess($uid);
                        $data['smess'] = $this->home_model->getsentmess($uid);
                        $this->load->view('public/messages', $data);
                    }

                    
                }
        }
        else
            redirect('home/login');
    }

    public function sendmessage() {
        
       $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $uid = $this->session->userdata('uid');
            $this->load->model('home_model');
            $data['mypapers'] = $this->home_model->retrievmysubpapers($uid);
            $this->load->view('public/sendmessage', $data);
        }
        else
            redirect('home/login');
    }

    public function send_message(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            $uid = $this->session->userdata('uid');
            $paid = $this->input->post('paid');
            $message = $this->input->post('message');
            $file1 = $_FILES['fileup']['name'];

            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            
                $filename = 'reply'.'_'.$paid.'_'.time();                         
                            
                if (!empty($file1)) {    
                    $config['upload_path'] = './papers/';
                    $config['allowed_types'] = 'docx';
                    $config['max_size'] = '2000';
                    $config['max_width']  = '1590';
                    $config['max_height']  = '900';
                    $config['overwrite']  = TRUE;
                    $config['file_name'] = $filename;

                    $this->load->library('upload', $config);
                        
                    if (empty($message)){
                        $_SESSION['errorstatus'] = -1;
                        $_SESSION['logoerror'] = -2;
                        $this->load->view('public/sendmessage', $data);
                    }
                    else
                    {
                        if ( ! $this->upload->do_upload('fileup'))
                        {
                            $_SESSION['errorstatus'] = -1;
                            $_SESSION['logoerror'] = -3; 
                            $this->load->view('public/sendmessage', $data);      
                        }
                        else
                        {   
                            $result = $this->home_model->send_message($uid, $filename);
                            $data['rmess'] = $this->home_model->getreceivedmess($uid);
                            $data['smess'] = $this->home_model->getsentmess($uid);
                            $this->load->view('public/messages', $data);
                        }
                    }
                }
                else
                {
                    if (empty($message)){
                        $_SESSION['errorstatus'] = -1;
                        $_SESSION['logoerror'] = -2;
                        $this->load->view('public/sendmessage', $data);
                    }
                    else
                    {
                        $filename = 0;
                        $result = $this->home_model->send_message($uid, $filename);
                        $data['rmess'] = $this->home_model->getreceivedmess($uid);
                        $data['smess'] = $this->home_model->getsentmess($uid);
                        $this->load->view('public/messages', $data);
                    }

                    
                }
        }
        else
            redirect('home/login');
    }

    public function submit_paper(){
        
        $user_data = $this->session->userdata('user_data');
        if (isset($user_data) AND $this->session->userdata('logged_in') == true)
        {
            //print_r($this->input->post());
            //exit();

            $uid = $this->session->userdata('uid');
            $title = $this->input->post('title');
            $authors = $this->input->post('authors');
            $abstract = $this->input->post('abstract');
            $file1 = $_FILES['fileup']['name'];

            $data['css'] = $this->load->view('global/publicss_depends', '', TRUE);
            $data['js'] = $this->load->view('global/publicjs_depends', '', TRUE);
            $data['footer'] = $this->load->view('global/public_footer', '', TRUE);
            $data['menu'] = $this->load->view('global/public_menuinner', '', TRUE);

            $this->load->model('home_model');
            
                $filename = 'paper'.'_'.$uid.'_'.time();                         
                            
                if (!empty($file1)) {    
                    $config['upload_path'] = './papers/';
                    $config['allowed_types'] = 'docx';
                    $config['max_size'] = '2000';
                    $config['max_width']  = '1590';
                    $config['max_height']  = '900';
                    $config['overwrite']  = TRUE;
                    $config['file_name'] = $filename;

                    $this->load->library('upload', $config);
                        
                    if (empty($title) OR empty($authors) OR empty($abstract)){
                        $_SESSION['logoerror'] = -2;
                        redirect('home/subpapers');
                    }
                    else
                    {

                        if ( ! $this->upload->do_upload('fileup'))
                        {
                            $_SESSION['errorstatus'] = -1;
                            $_SESSION['logoerror'] = -3;
                            redirect('home/subpapers');       
                        }
                        else
                        {   
                            $result = $this->home_model->submit_paper($uid, $filename);
                            $_SESSION['errorstatus'] = -1;
                            $_SESSION['logoerror'] = -7;
                            redirect('home/subpapers');
                        }
                    }
                }
                else
                {
                   
                    $_SESSION['errorstatus'] = -1;
                    $_SESSION['logoerror'] = -4;
                    redirect('home/subpapers');
                }
        }
        else
            redirect('home/login');
    }

    public function downloadpdf()
    {
        
        $fileid = $this->uri->segment(3);
        
        $this->load->model("home_model");
        $result = $this->home_model->retrievefilename($fileid);
        $this->load->helper('download');
        
        $filepath = site_url("/papers/") . '/' . $fileid . '.pdf';
        $data = file_get_contents($filepath); // Read the file's contents

        $name = $result->title . '.' . 'pdf';
        force_download($name, $data); 
    }

    public function downloadpdfp()
    {
        
        $fileid = $this->uri->segment(3);
        
        $this->load->model("home_model");
        $result = $this->home_model->retrievefilenamep($fileid);
        $this->load->helper('download');
        
        $filepath = site_url("/papers/") . '/' . $fileid . '.doc';
        $data = file_get_contents($filepath); // Read the file's contents

        $name = $result->title . '.' . 'doc';
        force_download($name, $data); 
    }

    

    
}