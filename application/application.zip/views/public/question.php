<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                                
                <!--Column-->
                <div class="column form-column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>Retrieve <span class="theme_color">Password</span></h3>
                        </div>
                        
                        <div class="default-form">
                            <form method="post" id="frmreview" name="frmreview">
                                 
                                <div class="row clearfix">
                                    <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                        <input type="hidden" id="emailaddress" name="emailaddress" value="<?php echo $this->session->userdata('emailaddress'); ?>">
                                    </div>
                                    <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                        <input type="text" disabled="disable" value="<?php echo $this->session->userdata('question'); ?>">
                                    </div>
                                    <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                        <input type="text" id="answer"  name="answer" value="" placeholder="You Secret Question Answer*" tabindex="1">
                                    </div>
                                </div>
                                <button type="submit" id="btn_review" class="theme-btn btn-style-one">Send Answer</button>
                            </form>
                            
                        </div>
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>

    <script>
            
        $(document).ready(function(){
                            
            $("#btn_review").click(function(e) {
                e.preventDefault();

                var emailaddress = $.trim($("#emailaddress").val()); 
                var answer = $.trim($("#answer").val());
               
                

                if (answer==''){
                    alert('Answer is required');
                    return;
                }
                 
                var Values = "&emailaddress="+emailaddress+"&answer="+answer;
                
                //alert(Values);
                //extrastrings="&ids="+checkValues;
                $.ajax({
                    url: "<?php echo site_url('home/submit_answer'); ?>",
                    type: "POST",
                    data: $("#frmreview").serialize()+Values,
                    //data: checkValues,
                    success: function (data) {
                        //alert (data);
                        $('#msg').html('');
                        if (data == 1) {
                            alert('Integrity Confirmed'); //return false;
                            window.location.href="<?php echo site_url('home/newpass'); ?>"
                        }
                        else if (data == 2){
                            alert('wrong Answer, Please Contact JOLUDS ADMIN');
                        }
                        else if (data == 0){
                            alert('No Such User');
                        }
                       
                        
                    }
                });
              })
            
        });

    </script>
</body>

</html>
