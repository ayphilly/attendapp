<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS Publications</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    
       
    <!--Gallery Section-->
    <section class="gallery-section">
    	<div class="auto-container">
            
            <div class="mixitup-gallery">
            	<div class="gallery-title"><h2>Our Published Volumes</h2></div>
                
        		<!--Filter-->
                <div class="filters right-aligned">
                    <ul class="filter-tabs filter-btns clearfix">
                        <li class="active filter" data-role="button" data-filter="all"></li>
                    </ul>
                </div>
                
                <!--Filter List-->    
                <div class="filter-list row clearfix">
                    <?php if(isset($volumes)) {
                        foreach($volumes as $row) {
                    ?>
                        <!--Our Published Journals-->
                        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 default-portfolio-item all ">
                            <div class="inner-box">
                                <figure class="image-box"><a href="<?php echo base_url() . 'papers/'.$row->image.'.jpg'; ?>" class="lightbox-image" title="<?php echo $row->volumename; ?>" data-fancybox-group="example-gallery"><img src="<?php echo base_url() . 'papers/'.$row->image.'.jpg'; ?>" alt=""></a></figure>
                                <!--Caption Box-->
                                <div class="caption-box">
                                    <h4><a href="<?php echo base_url() . 'home/volume/' . $row->vid; ?>"><?php echo $row->volumename; ?></a></h4>
                                    <a href="<?php echo base_url() . 'home/volume/' . $row->vid; ?>" class="icon"><span class="flaticon-arrows-17"></span></a>
                                </div>
                            </div>
                        </div>
                    <?php } } ?>
                </div>
                
            </div>
        </div>
    </section>
    
    
    <!--Testimonial Style One-->
    <section class="testimonial-style-one" style="background-image:url(<?php echo base_url() . 'assetsp/images/background/image-1.jpg'; ?>);">
    	
        <div class="auto-container">
        <h2>Editorial <span class="theme_color">Team</span></h2>
            <!--Testimonial Carousel-->
            <div class="testimonial-carousel three-column-carousel">
                <?php if(isset($editor)) {
                  foreach($editor as $row) {
                ?>
                    <!--Slide Item-->
                    <div class="slide-item">
                        <div class="inner-box">
                            <figure class="author-image"><img src="<?php echo base_url() . 'assetsp/images/staff.jpg'; ?>" alt=""></figure>
                            <h4><?php echo $row->salutation.' '. $row->lastname.' '.$row->firstname.'. '.$row->middlename.'. '; ?></h4>
                            <div class="text"><?php echo $row->address; ?></div>
                            
                        </div>
                    </div>
                <?php } } ?>
                
            </div>
                
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>
</body>

</html>
