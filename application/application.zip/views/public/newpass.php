<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                                
                <!--Column-->
                <div class="column form-column col-lg-6 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>Reset <span class="theme_color"> Password</span></h3>
                        </div>
                        
                        <div class="default-form">
                        <form method="post" id="frmreview" name="frmreview">
                            <div class="row clearfix">
                                 <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                        <input type="hidden" id="uid" name="uid" value="<?php echo $this->session->userdata('uid'); ?>">
                                    </div>
                                <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                    <input type="password" name="newpassword"  id="newpassword" value="" placeholder="Password *" tabindex="2">
                                </div>
                                <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                    <input type="password" name="password"  id="password" value="" placeholder="Confirm Password *" tabindex="2">
                                </div>
                            </div>
                            <button type="submit" id="btn_review" class="theme-btn btn-style-one">Set News Password</button>
                            
                        </form>
                        
                    </div>
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>

    <script>
            
        $(document).ready(function(){
                            
            $("#btn_review").click(function(e) {
                e.preventDefault();
                var uid = $.trim($("#uid").val()); 
                var password = $.trim($("#password").val()); 
                var newpassword = $.trim($("#newpassword").val());
               
                

                if (password==''){
                    alert('Email address is required');
                    return;
                }
                else if (newpassword==''){
                     alert('The Password is required');
                     return;
                }
                else if (newpassword != password){
                     alert('Passwords not matched');
                     return;
                }
                 
                var Values = "&newpassword="+newpassword+"&password="+password+"&uid="+uid;
                
                //alert(Values);
                //extrastrings="&ids="+checkValues;
                $.ajax({
                    url: "<?php echo site_url('home/submit_newpass'); ?>",
                    type: "POST",
                    data: $("#frmreview").serialize()+Values,
                    //data: checkValues,
                    success: function (data) {
                        //alert (data);
                        $('#msg').html('');
                        if (data == 1) {
                            alert('Credentials Confirmed'); //return false;
                            window.location.href="<?php echo site_url('home/login'); ?>"
                        }
                        else if (data == 2){
                            alert('Account Disabled');
                        }
                        else if (data == 3){
                            alert('Wrong Password');
                        }
                        else if (data == 0){
                            alert('No user with such credentials');
                        }
                        
                    }
                });
              })
            
        });

    </script>
</body>

</html>
