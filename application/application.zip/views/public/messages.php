<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS | My Messages</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    <!--End Main Header -->
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-3 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                       <ul class="info-list">
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/profile'); ?>"> 
                            <i class="fa fa-home"></i> My Profile </a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/mysubpapers'); ?>"> 
                            <i class="fa fa-list-ul"></i> My Papers </a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/subpapers'); ?>"> 
                            <i class="fa fa-pencil-square"></i> Send a Paper</a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/messages'); ?>"> 
                            <i class="fa fa-long-arrow-down"></i> Messages</a></li>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-9 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>SENT and RECEIVED <span class="theme_color">MESSAGES <a href="<?php echo site_url('/home/sendmessage'); ?>" class="theme-btn btn-style-one">New Message</a></span></h3> 
                           <!--  <div class="text">Attach and the paper to be reviewed</div> -->
                        </div>
                       <!-- Recent Articles -->
                                               
                        <ul class="accordion-box style-two">
                                
                                <!--Block-->
                                <li class="accordion block wow fadeInUp active-block" data-wow-delay="0ms" data-wow-duration="1500ms">
                                    <div class="acc-btn active"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-down"></span> <span class="icon icon-minus fa fa-angle-up"></span></div>SENT MESSAGES</div>
                                    <div class="acc-content current">
                                        <div class="content clearfix">
                                            <p>
                                                 <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                                    <div class="content-block">
                                                        <div class="default-title"><h3></h3></div>
                                                        <?php if(isset($smess)) {
                                                          foreach($smess as $row) {
                                                        ?>
                                                            <ul>
                                                                <li><strong>Paper Title :</strong><?php echo $row->title; ?></li>
                                                                <li><strong>Author(s) :</strong> <?php echo $row->authors; ?></li>
                                                                <li><strong>Receive Date:</strong> <?php echo $row->datesent; ?></li>
                                                            </ul>
                                                            <div class="text"><strong>Message:- </strong><?php echo $row->message; ?></div>
                                                            <div class="widget sidebar-widget downloads">
                                                                <ul>
                                                                   
                                                                        <li><a href="<?php echo base_url().'home/downloadpdfp/'.$row->mfile; ?>"><span class="icon fa fa-file-docx-o"></span> Download.File</a></li>
                                                                     
                                                                </ul>
                                                               
                                                            </div>
                                                            <hr style="border-color: #11A;" />
                                                        <?php } } ?>
                                                    </div>
                                                
                                                </div>

                                            </p>
                                        </div>
                                    </div>
                                </li>
                                
                                <!--Block-->
                                <li class="accordion block wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                                    <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-angle-down"></span> <span class="icon icon-minus fa fa-angle-up"></span></div>RECEIVED MESSAGES</div>
                                    <div class="acc-content">
                                        <div class="content clearfix">
                                            <p>
                                                <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                                    <div class="content-block">
                                                        <div class="default-title"><h3></h3></div>
                                                        <?php if(isset($rmess)) {
                                                          foreach($rmess as $row) {
                                                        ?>
                                                            <ul>
                                                                <li><strong>Paper Title :</strong><?php echo $row->title; ?></li>
                                                                <li><strong>Author(s) :</strong> <?php echo $row->authors; ?></li>
                                                                <li><strong>Receive Date:</strong> <?php echo $row->datesent; ?></li>
                                                            </ul>
                                                            <div class="text"><?php echo $row->message; ?></div>
                                                            <div class="widget sidebar-widget downloads">
                                                                <ul>
                                                               
                                                                     
                                                                    <li><a href="<?php echo base_url().'home/downloadpdfp/'.$row->mfile; ?>"><span class="icon fa fa-file-docx-o"></span> Download.File</a></li>
                                                                   
                                                                </ul>
                                                                <a href="<?php echo base_url() . 'home/replymail/' .$row->msid; ?>" class="theme-btn btn-style-two">Reply</a>
                                                            </div>
                                                            <hr />
                                                        <?php } } ?>
                                                    </div>
                                                
                                                </div>


                                            </p>
                                        </div>
                                    </div>
                                </li>
                                
                               
                                
                            </ul><!--End Accordion Box-->
                        
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>
 <?php $_SESSION['errorstatus'] = 0; $_SESSION['logoerror'] = 0; ?>

</body>

</html>
