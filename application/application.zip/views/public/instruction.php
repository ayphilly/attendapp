<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS | About Us</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    <!--End Main Header -->
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-4 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <ul class="info-list">
                            <?php if(isset($volumes)) {
                                foreach($volumes as $row) {
                            ?>
                                <li class="btn-style-one col-lg-12">
                                <a href="<?php echo base_url() . 'home/volume/' . $row->vid; ?>"> 
                                <i class="fa fa-location-arrow"></i> <?php echo $row->volumename; ?> </a></li>
                            <?php } } ?>
                        </ul>
                        <ul class="info-list">
                            <?php if(isset($fpapers)) {
                                foreach($fpapers as $row) {
                            ?>
                                <li class="btn-style-one col-lg-12">
                                <a href="<?php echo base_url() . 'home/volume/' . $row->vid; ?>"> 
                                <i class="fa fa-location-arrow"></i> <?php echo $row->volumename; ?> </a></li>
                            <?php } } ?>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-8 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>INSTRUCTION TO <span class="theme_color"> AUTHOR(S)</span></h3>
                           <!--  <div class="text">Attach and the paper to be reviewed</div> -->
                        </div>
                        <aside class="sidebar">
                                                                 
                            <!-- Recent Articles -->
                            <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                
                               <p>The Journal of Land Use and Development Studies hereby invites articles for publication in its next publication from Natural and Built Environmental Studies. The proposed journal articles MUST adhere to our instruction and guidelines as contained in the Instruction to Authors manual to qualify for pre-selection for possible publication.</p>

                                <h4><strong>INSTRUCTION TO AUTHORS</strong></h4>
                               <p> Unless otherwise stated in any edition of the Journal of Land use and Development Studies, manuscripts submitted for publications will follow the Instructions below:</p>

                                <h4><strong>SUBMISSION</h4>
                                <p> All submission are to be online, and this could be done after registration</p>

                               <p>
                                <h4><strong>The Manuscript</strong></h4>
                                <ul>
                                    <li>--Articles should be analytical and rigorous, not merely descriptive</li>
                                    <li>--The length of paper should not be more than fifteen pages on A4 sheet at 12 font size and Times New Roman font type within the range of 1000 to 4000 words, typed in double spacing and with wide margin.</li>
                                    <li>--All the pages should be numbered consecutively and should be arranged under headings and subheadings.</li>
                                   
                                </ul>
                                </p>
                                    
                               
                                <p>
                                <h4><strong>Cover Page</strong></h4>
                                The cover page should contain the following information
                                
                                <ul>
                                    <li>--The author(s) name(s) and affiliation, postal address, email and fax numbers.</li>
                                    <li>--A running title of not more than 80 characters.</li>
                                    <li>--The name and address of the author who will be responsible for correspondence.</li>
                                    <li>--The first page of text should show the title of the paper but no author(s) name(s) or affiliation.</li>
                                   
                                </ul>
                                   
                                </p>
                                <p> 
                                <h4><strong>Abstracts</strong></h4>
                               Authors are expected to include an abstract of not more than 200 words summarizing the purpose and objectives, methodology, major findings and conclusion of the paper.</p>

                              <p> <h4>Keywords</h4>
                                Authors are expected to produce 4-6 keywords that clearly describe the subject matter of the paper.</p>   
                                
                                <p><h4><strong>Table</strong></h4>
                                <ul>
                                    <li>--Tables should be numbered consecutively in roman numerals and labeled as Table I, Table II, etc together with brief title and source.</li>
                                    <li>--Table should be placed at the appropriate place in the text.</li>
                                </ul></p>
                                

                                <p><h4><strong>Figures</strong></h4>
                                <ul>
                                    <li>--Figures should be numbered consecutively in Arabic numerals and labeled as Figure 1, Figure 2, etc together with brief title and source</li>
                                    <li>--Figures should be placed at the appropriate place in the text.</li>
                                   
                                </ul>
                                </p>
                                <p>
                                <h4><strong>References</strong></h4>
                                <ul>
                                    <li>--References to other publications should be in APA style.</li>
                                    <li>--Cite other works in the text with author's last name (without title) and year eg. Bello (2003). If more than two authors, it should appear as Asaju et al (2003)</li>
                                    <li>--Reference to different works of the same author in the same year should be differentiated by using a, b etc. e.g. Okoko (2000 a), Okoko (2000 b)</li>
                                    <li>--A short bibliography, acknowledgement and suggestion for further reading are also acceptable</li>

                                    <li>--Journal of Land Use and Development Studies</li>
                                    <li>--Reference to electronic journal should include authors name, year, title of work, journal title, volume (issues), pages, web address (accesses date).</li>
                                </ul>                                    
                                </p>
                                <p><h4><strong>End  Note</strong></h4>
                                <ul>
                                    <li>--Footnotes are not acceptable</li>
                                    <li>--Use explanatory notes only if they cannot be readily included in the text</li>
                                    <li>--Explanatory notes should be presented on a separate sheet and numbered consecutively in the text and denoted by superscripts</li>
                                </ul></p>
                                    

                            </div>

                        </div>
                        
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>


</body>

</html>
