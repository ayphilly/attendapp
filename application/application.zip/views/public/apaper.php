<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS |<?php if(isset($apaper)) echo $apaper->title; ?> </title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    <!--End Main Header -->
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-4 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <ul class="info-list">
                            <?php if(isset($volumes)) {
                                foreach($volumes as $row) {
                            ?>
                                <li class="btn-style-one col-lg-12">
                                <a href="<?php echo base_url() . 'home/volume/' . $row->vid; ?>"> 
                                <i class="fa fa-location-arrow"></i> <?php echo $row->volumename; ?> </a></li>
                            <?php } } ?>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-8 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<aside class="sidebar">
                                                                 
                            <!-- Recent Articles -->
                            <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                               <div class="content-block">
                                    <div class="default-title"><h3>Paper Details</h3></div>
                                    <ul>
                                        <li><strong>Title :</strong><?php if(isset($apaper)) echo $apaper->title; ?></li>
                                        <li><strong>Author(s) :</strong> <?php if(isset($apaper)) echo $apaper->authors; ?></li>
                                        <li><strong>Abstract:</strong> </li>
                                    </ul>
                                    <div class="text"><?php if(isset($apaper)) echo $apaper->abstract; ?></div>
                                    <div class="widget sidebar-widget downloads">
                                        <ul>
                                            <li><a href="<?php echo base_url().'home/downloadpdf/'.$apaper->file; ?>"><span class="icon fa fa-file-pdf-o"></span> Download.PDF</a></li>
                                        </ul>
                                    </div>
                                    
                                </div>

                        </div>
                        
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>


</body>

</html>
