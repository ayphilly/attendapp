<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS My Profile</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    <!--End Main Header -->
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-3 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                       <ul class="info-list">
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/profile'); ?>"> 
                            <i class="fa fa-home"></i> My Profile </a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/mysubpapers'); ?>"> 
                            <i class="fa fa-list-ul"></i> My Papers </a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/subpapers'); ?>"> 
                            <i class="fa fa-pencil-square"></i> Send a Paper</a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/messages'); ?>"> 
                            <i class="fa fa-long-arrow-down"></i> Messages</a></li>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-9 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>Submited <span class="theme_color">Papers</span></h3>
                           <!--  <div class="text">Attach and the paper to be reviewed</div> -->
                        </div>
                       <!-- Recent Articles -->
                            <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                               <div class="content-block">
                                    <div class="default-title"><h3></h3></div>
                                    <?php if(isset($mypapers)) {
                                      foreach($mypapers as $row) {
                                    ?>
                                        <ul>
                                            <li><strong>Title :</strong><?php echo $row->title; ?></li>
                                            <li><strong>Author(s) :</strong> <?php echo $row->authors; ?></li>
                                            <li><strong>Abstract:</strong> </li>
                                        </ul>
                                        <div class="text"><?php echo $row->abstract; ?></div>
                                        <div class="widget sidebar-widget downloads">
                                            <ul>
                                                <li><a href="<?php echo base_url().'home/downloadpdfp/'.$row->file; ?>"><span class="icon fa fa-file-pdf-o"></span> Download FILE</a></li>
                                            </ul>
                                        </div>
                                        <hr />
                                    <?php } } ?>
                                </div>


                        </div>
                        
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>
 <?php $_SESSION['errorstatus'] = 0; $_SESSION['logoerror'] = 0; ?>

</body>

</html>
