<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS My Profile</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
   <?php echo $menu; ?>
    <!--End Main Header -->
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-3 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <ul class="info-list">
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/user'); ?>"> 
                            <i class="fa fa-location-arrow"></i> My Papers </a></li>
                             <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/subpapers'); ?>"> 
                            <i class="fa fa-location-arrow"></i>Submit Paper</a></li>
                             <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/profile'); ?>"> 
                            <i class="fa fa-location-arrow"></i> My Profile </a></li>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-9 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>My Profile<span class="theme_color"> </span></h3>
                           <!--  <div class="text">Attach and the paper to be reviewed</div> -->
                        </div>
                        <aside class="sidebar">
                                                                 
                            <!-- Recent Articles -->
                            <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <ul class="list">
                                    <li><a href="#" class="clearfix"><?php if(isset($profile)) echo $profile->lastname . ' '. $profile->firstname . ' ' . $profile->middlename; ?></a></li>
                                    <li><a href="#" class="clearfix"><?php if(isset($profile)) echo $profile->emailaddress; ?> </a></li>
                                    <li><a href="#" class="clearfix"><?php if(isset($profile)) echo $profile->emailaddress; ?></a></li>
                                    <li><a href="#" class="clearfix"><?php if(isset($profile)) echo $profile->emailaddress; ?></a></li>
                                    <li><a href="#" class="clearfix"><?php if(isset($profile)) echo $profile->emailaddress; ?></a></li>
                                </ul>
                            </div>

                        </div>
                        
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>
 <?php $_SESSION['errorstatus'] = 0; $_SESSION['logoerror'] = 0; ?>

</body>

</html>
