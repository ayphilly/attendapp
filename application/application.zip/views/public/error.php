<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS</title>

<?php echo $css; ?>
</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    
    
    <!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo base_url() . 'assetsp/images/background/page-title-4.jpg'; ?>);">
        <div class="auto-container">
            <h1>ERROR 404</h1>
        </div>
    </section>   
    
    <!--Welcome Section-->
    <section class="welcome-section">
    	<div class="auto-container">
    		<div class="welcome-content">
            	<!--Section Title-->
                <div class="sec-title">
                	<h2>ERROR <span class="theme_color">PAGE NOT FOUND</span></h2>
                </div>
            </div>
        </div>
    </section>
 
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>
</body>

</html>
