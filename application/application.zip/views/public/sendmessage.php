<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS | </title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-3 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                       <ul class="info-list">
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/profile'); ?>"> 
                            <i class="fa fa-home"></i> My Profile </a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/mysubpapers'); ?>"> 
                            <i class="fa fa-list-ul"></i> My Papers </a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/subpapers'); ?>"> 
                            <i class="fa fa-pencil-square"></i> Send a Paper</a></li>
                            <li class="btn-style-one col-lg-12">
                            <a href="<?php echo site_url('/home/messages'); ?>"> 
                            <i class="fa fa-long-arrow-down"></i> Messages</a></li>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-9 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>SEND A <span class="theme_color"> </span>Message</h3>
                           
                        </div>
                        
                        
                        
                        <div class="default-form">
                        <?php 
                            //echo $_SESSION['errorstatus'];
                            if ($_SESSION['errorstatus']== -1) {
                                
                                //echo $_SESSION['advertstatus'];

                                if($_SESSION['logoerror'] == -3) { ?>
                                    <h2 <strong style="color: #A00;">Error! </strong>
                                    File can't be more than 2Meg and Only a PDF File</h2>
                                
                                <?php }
                                elseif ($_SESSION['logoerror'] == -2) { ?>
                                    <h2 <strong style="color: #A00;">Error! </strong>
                                    Paper Title, Author and Abtract required</h2>
                                <?php }

                                elseif ($_SESSION['logoerror'] == -4) { ?>
                                    <h2 ><strong style="color: #A00;">Error! </strong>No PDF File Selected</h2>                     
                        <?php } } ?>
                        <form  method="post" action="<?php echo base_url() . 'home/send_message'; ?>" enctype="multipart/form-data">
                            <div class="row clearfix">
                                <input type="hidden" name="uid" value="<?php echo $this->session->userdata('uid'); ?>"/>
                                <input type="hidden" name="emailaddress" value="<?php echo $this->session->userdata('emailaddress'); ?>"/>
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <select name="paid" id="paid" data-placeholder="Select Sex" class="select2 span12 spclear" tabindex="2">
                                        <option value="">Select Related Paper</option>
                                        <?php foreach ($mypapers as $pa) { ?>
                                        <option value="<?php echo $pa->paid; ?>">
                                            <?php echo $pa->title; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <textarea name="message" id="message" placeholder="Message to JOLUDS admin here" required tabindex="3"></textarea>
                                </div>
                                 <div class="form-group col-md-12 col-sm-6 col-xs-12">
                                   <input type="file" name="fileup" class="default" />
                                </div>
                            </div>
                            
                            <button type="submit" id="btn_review" class="theme-btn btn-style-one">Send Reply</button>
                            
                        </form>
                        
                        
                    </div>
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>
 <?php $_SESSION['errorstatus'] = 0; $_SESSION['logoerror'] = 0; ?>

</body>

</html>
