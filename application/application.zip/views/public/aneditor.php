<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS |<?php if(isset($apaper)) echo $apaper->title; ?> </title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>
    <!--End Main Header -->
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                <div class="column info-column col-lg-4 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <ul class="info-list">
                            <?php if(isset($volumes)) {
                                foreach($volumes as $row) {
                            ?>
                                <li class="btn-style-one col-lg-12">
                                <a href="<?php echo base_url() . 'home/volume/' . $row->vid; ?>"> 
                                <i class="fa fa-location-arrow"></i> <?php echo $row->volumename; ?> </a></li>
                            <?php } } ?>
                        </ul>
                    </div>
                </div>
                
                <!--Column-->
                <div class="column form-column col-lg-8 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<aside class="sidebar">
                                                                 
                            <!-- Recent Articles -->
                            <div class="sidebar-widget recent-articles wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                               <div class="content-block">
                                    <div class="default-title"><h3>Editor Details</h3></div>
                                    <figure class="image-box">
                        <a href="<?php echo base_url() . 'assetsp/images/staff.jpg'; ?>" class="lightbox-image" title="Image Caption Here" data-fancybox-group="example-gallery"><img src="<?php echo base_url() . 'users/'.$editor->image.'.jpg'; ?>" alt=""></a></figure>
                                    <ul>
                                        <li><strong>Fullname: </strong><?php if(isset($editor)) echo $editor->salutation.' '. $editor->lastname.' '.$editor->firstname.'. '.$editor->middlename.'. '; ?></li>
                                        <li><strong>University: </strong> <?php if(isset($editor)) echo $editor->university; ?></li>
                                        <li><strong>Address: </strong><?php if(isset($editor)) echo $editor->address; ?></li>
                                        <li><strong>Gender: </strong><?php if(isset($editor)) echo $editor->gender; ?></li><!-- 
                                        <li><strong>Email:</strong><?php if(isset($editor)) echo $editor->emailaddress; ?></li> -->
                                    </ul>
                                    
                                    
                                </div>

                        </div>
                        
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>


</body>

</html>
