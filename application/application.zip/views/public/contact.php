<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>JOLUDS Contact Info</title>

<?php echo $css; ?>

</head>

<body>
<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <?php echo $menu; ?>  
 
    
    <!--Contact Style One-->
    <section class="contact-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--Column-->
                
                
                <!--Column-->
                <div class="column form-column col-lg-12 col-md-6 col-sm-12 col-xs-12">
                	<div class="info-box">
                    	<div class="upper-content">
                            <h3>Contact our <span class="theme_color">support team</span></h3>
                            <div class="text">Send us a Message</div>
                        </div>
                        
                        <div class="default-form">
                        <form method="post" id="frmreview" name="frmreview">
                            <div class="row clearfix">
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="fullname" name="fullname" value="" placeholder="Your Fullname *" required>
                                </div>
                                
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <input type="email" id="emailaddress" name="emailaddress" value="" placeholder="Your Email *" required>
                                </div>
                                
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="phonenumber" name="phonenumber" value="" placeholder="Your Phone *" required>
                                </div>
                                
                                <div class="form-group col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" id="subject" name="subject" value="" placeholder="Message Subject *">
                                </div>
                                
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <textarea id="message" name="message" placeholder="Your Message" required></textarea>
                                </div>
                                 <div class="form-group col-md-3 col-sm-6 col-xs-12">
                                   <input type="hidden" value="<?php echo $capcha ?>" id="captchword" name="captchword">
                                   <div style="color: #fff; font-family:Bradly; background-color:#009;font-size: 28px; height: 40px; text-align: center;">
                                            <?php echo $capcha ?></div>If you are not a robot
                                </div>
                                <div class="form-group col-md-3 col-sm-6 col-xs-12">
                                    <input type="text" name="captchaenter" id="captchaenter" placeholder="Enter CAPCHA *" tabindex="11">
                                </div>
                            </div>
                            
                            <button type="submit" id="btn_review" class="theme-btn btn-style-one">Send Message</button>
                            
                        </form>
                        
                    </div>
                    
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <?php echo $footer; ?>
    
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<?php echo $js; ?>

<script>
            
        $(document).ready(function(){
                            
            $("#btn_review").click(function(e) {
                e.preventDefault();
                var fullname        = $.trim($("#fullname").val()); 
                var subject         = $.trim($("#subject").val());
                var emailaddress    = $.trim($("#emailaddress").val());  
                var message         = $.trim($("#message").val()); 
                var phonenumber     = $.trim($("#phonenumber").val()); 
                var captchaenter    = $.trim($("#captchaenter").val()); 
                var captchword      = $.trim($("#captchword").val()); 
               
                //alert(backing5);

                if (captchword!=captchaenter){
                     alert('The captcha Letter is not correct');
                     return;
                }

                
                var Values = "&fullname="+fullname+"&subject="+subject+"&emailaddress="+emailaddress+"&message="+message+"&phonenumber="+phonenumber;
                
                //alert(Values);
                //extrastrings="&ids="+checkValues;
                $.ajax({
                    url: "<?php echo site_url('home/submit_contact'); ?>",
                    type: "POST",
                    data: $("#frmreview").serialize()+Values,
                    //data: checkValues,
                    success: function (data) {
                        //alert (data);
                        $('#msg').html('');
                        if (data == 1) {
                            alert('Message Sent Successful, We will get back to you soon'); //return false;
                        }
                        else if (data == 0){
                            alert('Error Sending Message ');
                        }
                        
                    }
                });
              })
            
        });

    </script>

</body>



</html>
