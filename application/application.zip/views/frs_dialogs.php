	<div id="questiondialog" class="modal hide fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
		<div class="modal-header">
			<h3>JOLUDS</h3>
		</div>
		<div class="modal-body">
			<p align="justify" id="questionmsg"></p>
		</div>
		<div class="modal-footer">
			<button type="button" data-dismiss="modal" class="btn purple">Continue Task</button>
			<button type="button"  class="btn" id="dtcancel">OK</button>
		</div>
	</div>	

	<div id="saveddialog" class="modal hide fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
		<div class="modal-header">
			<h3>JOLUDS</h3>
		</div>
		<div class="modal-body">
			<p>Record saved successfully</p>
		</div>
		<div class="modal-footer">
			<button type="button" data-dismiss="modal" class="btn purple">OK</button>
		</div>
	</div>

	<div id="updateddialog" class="modal hide fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
		<div class="modal-header">
			<h3>JOLUDS</h3>
		</div>
		<div class="modal-body">
			<p>Record updated successfully</p>
		</div>
		<div class="modal-footer">
			<button type="button" data-dismiss="modal" class="btn purple">OK</button>
		</div>
	</div>

	<div id="errordialog" class="modal hide fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
		<div class="modal-header">
			<h3>JOLUDS</h3>
		</div>
		<div class="modal-body">
			<p>Unknown error occured! Please contact the administrator</p>
		</div>
		<div class="modal-footer">
			<button type="button" data-dismiss="modal" class="btn red">OK</button>
		</div>
	</div>
	<div id="anydialog" class="modal hide fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
			<h3>JOLUDS Message</h3>
		</div>
		<div class="modal-body">
			<p align="justify"><span id="anymsg" name="anymsg"></span></p>
		</div>
		<div class="modal-footer">
			<button type="button"  data-dismiss="modal" class="btn red" id="anyOK" name="anycancel">OK</button>
		</div>
	</div>

	<div id="notfounddialog" class="modal hide fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
		<div class="modal-header">
			<h3>JOLUDS</h3>
		</div>
		<div class="modal-body">
			<p>Registration Number not found.</p>
		</div>
		<div class="modal-footer">
			<button type="button" data-dismiss="modal" class="btn red">OK</button>
		</div>
	</div>

	<div id="reginfodialog" class="modal container hide fade" tabindex="-1" data-backdrop="static" data-keyboard="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
			<h3>INSTRUCTION TO USERS</h3>
		</div>
		<div class="modal-body">
			<p>
				I.	For a fresh candidate that has no account, click on “Fill Application Form”  link<br/>
				II.	Enter your Surname, Othernames, Phone Number, Email Address and Password, Use your personal phone number and email address,
				     or that of the parent as these will be the channel of communicating to you throughout your stay in the School. Then click on Create 
				     Account to Create a Student Account.<br/>
				
			</p>
		</div>
		<div class="modal-footer">
			<button type="button" data-dismiss="modal" class="btn blue">Proceed</button>
		</div>
	</div>


	<a id="openquestiondialog" class="btn" data-toggle="modal" href="#questiondialog" style="display:none"></a>						
	<a id="opensaveddialog" class="btn" data-toggle="modal" href="#saveddialog" style="display:none"></a>						
	<a id="openupdateddialog" class="btn" data-toggle="modal" href="#updateddialog" style="display:none"></a>						
	<a id="openerrordialog" class="btn" data-toggle="modal" href="#errordialog" style="display:none"></a>
	<a id="openanydialog" class="btn" data-toggle="modal" href="#anydialog" style="display:none"></a>				
	<a id="opennotfounddialog" class="btn" data-toggle="modal" href="#notfounddialog" style="display:none"></a> 					
	<a id="openreginfodialog" class="btn" data-toggle="modal" href="#reginfodialog" style="display:none"></a>
