<html>
<head>
	<title>evrischool.comn</title>
</head>
<body>

<p> Site is coming soon</p>

<img src="assetsp/images/comingsoon.png'; ?>" alt="Coming Soon" >

</body>
</html>