<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>JOLUDS Admin | Edit Staff</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<?php echo $css; ?>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="page-header-fixed">
	<?php echo $dialogs; ?>
	<!-- BEGIN HEADER -->
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<?php echo $header; ?>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container row-fluid">
		<!-- BEGIN SIDEBAR -->
		<?php echo $sidebar; ?>
		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->  
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div id="portlet-config" class="modal hide">
				<div class="modal-header">
					<button data-dismiss="modal" class="close" type="button"></button>
					<h3>portlet Settings</h3>
				</div>
				<div class="modal-body">
					<p>Here will be a configuration form</p>
				</div>
			</div>
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT-->
				<p></p>
				<div class="row-fluid">
					<div class="span10">
						<div class="portlet box grey">
							<div class="portlet-title">
								<div  id="forminfo" class="caption"><i class="icon-reorder"></i> <span> EDIT <?php if(isset($staffid)) echo $staffid->fullname; ?> ACCOUNT</span> </div>
								
								<div class="tools">
									<a href="javascript:;" class="collapse"></a>
									<a href="javascript:;" class="reload"></a>
								</div>
							</div>

							<div class="portlet-body form">

								<form action="#" id="frmstaffdata" name="frmstaffdata" class="form-horizontal">
									<div class="alert alert-error hide">
										<button class="close" data-dismiss="alert"></button>
										You have some form errors. Please check below.
									</div>
									<div class="alert alert-success hide">
										<button class="close" data-dismiss="alert"></button>
										Your form validation is successful!
									</div>
									<h4 class="form-section">Personal Information</h4>
									<input type="hidden" name="userid" value="<?php echo $this->session->userdata('userid'); ?>"/>
									<input type="hidden" name="staffid" value="<?php if(isset($staffid)) echo $staffid->userid; ?>"/>
									
									
									<div class="row-fluid">
										<div class="span5">
											<div class="control-group">
												<label class="control-label">Fullname<span class="required">*</span></label>
												<div class="controls">
													<input type="text" id="fullname" name="fullname" class="m-wrap span12 xd" 
													 value="<?php if(isset($staffid)) echo $staffid->fullname; ?>" placeholder="Family Name">
												</div>
											</div>
										</div>
										<!--/span-->
										<div class="span5">
											<div class="control-group">
												<label class="control-label">Username<span class="required">*</span></label>
												<div class="controls">
													<input type="text" value="<?php if(isset($staffid)) echo $staffid->username; ?>"  
													id="username" disable=disabled name="username" class="m-wrap span12 xd" placeholder="Account Login Username">
												</div>
											</div>
										</div>
										<!--/span-->
									</div>
									<!--/row-->

									<div class="row-fluid">
										
										<!--/span-->
										<div class="span5 ">
											<div class="control-group">
												<label class="control-label">Department<span class="required">*</span></label>
												<div class="controls">
													<select name="department" id="department"  class="dropdown span12 select2_category xd" 
													 data-placeholder="Select Department" tabindex="1">
														<option value="<?php if(isset($staffid)) echo $staffid->department; ?>"> 
														<?php if(isset($staffid)) echo $staffid->status; ?></option>
														<option value="1">SUPER ADMIN</option>
														<option value="2">USER SUPPORT</option>
														<option value="4">DATA INPUTER</option>
														<option value="5">HR MANAGER</option>
														<option value="6">CMS ASSISTANT</option>
													</select>
												</div>
											</div>
										</div>
										<!--/span-->
										<div class="span5 ">
											<div class="control-group">
												<label class="control-label">Activate<span class="required">*</span></label>
												<div class="controls">
													<select name="userstatus" id="userstatus"  class="dropdown span12 select2_category xd" 
													 data-placeholder="Set Status" tabindex="1">
														<option value="<?php if(isset($staffid)) echo $staffid->userstatus; ?>"> 
														<?php if(isset($staffid)) echo $staffid->userstatus; ?></option>
														<option value="Enable">Enable</option>
														<option value="Disable">Disable</option>
													</select>
												</div>
											</div>
										</div>
										<!--/span-->
									</div>
									<!--/row-->
									<div class="row-fluid">
										<div class="span5 ">
											<div class="control-group">
												<label class="control-label">Phone Number<span class="required">*</span></label>
												<div class="controls">
													<input type="text"  id="phonenumber" name="phonenumber" class="m-wrap span12 xd" 
													placeholder="08012345678" value="<?php if(isset($staffid)) echo $staffid->phone; ?>">
												</div>
											</div>
										</div>
										<!--/span-->
									</div>
									<!--/row-->
									
									<div class="form-actions">
										<span id="msgsave" name="msgsave"></span>
										<button type="submit" id="cmdsavestaff" class="btn purple"><i class="icon-ok"></i> Save All</button>
										<button type="button" class="btn">Cancel</button>
									</div>
								</form>
								<!-- PICTURE UPLOAD FORM FOR STUDENTS-->

							</div>
						</div>
					</div>
				</div>
				<!-- BEGIN VIEW SESSION -->
				<div class="row-fluid">
					<div class="span12">
						<div class="span12 responsive" data-tablet="span12 fix-offset" data-desktop="span10">
						<!-- BEGIN EXAMPLE TABLE PORTLET-->
						<div class="portlet box grey">
							<div class="portlet-title">
								<div class="caption"><i class="icon-user"></i>Available Ads</div>
								
								<div class="actions">
									<a href="#" class="btn blue"><i class="icon-pencil"></i> Add</a>
									<div class="btn-group">
										<a class="btn green" href="#" data-toggle="dropdown">
										<i class="icon-cogs"></i> Tools
										<i class="icon-angle-down"></i>
										</a>
										<ul class="dropdown-menu pull-right">
											<li><a href="#"><i class="icon-trash"></i> Delete</a></li>
											<li class="divider"></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="portlet-body">
								<table class="table table-striped table-bordered table-hover" id="sample_2">
									<thead>
									
										<tr>
											<th style="width:8px;"><input type="checkbox" class="group-checkable" data-set="#sample_2 .checkboxes" /></th>
											<th>FULLNAME</th>
											<th>USERNAME</th>
											<th>STATUS</th>
											<th>ACTION</th>
											<th>Date</th>
										</tr>
									
									</thead>
									<tbody>
									<?php if(isset($staff)) {
										foreach($staff as $row) {
									?>
										<tr class="odd gradeX">
											<td><input type="checkbox" class="checkboxes" value="<?php echo $row->userid; ?>" /></td>
											<td><?php echo $row->fullname; ?></td>
											<td><?php echo $row->username ; ?></td>
											<td>
											<a href="" class="btn large blue-stripe"><?php echo $row->status ; ?></a>
											</td>
											<td>
											<a href="<?php echo base_url() . 'adminside/editstaff/' . $row->userid; ?>" class="btn mini blue"><i class="icon-edit"></i> E d i t </a><br />
											<a href="<?php echo base_url() . 'adminside/deletestaff/' . $row->userid; ?>" class="btn mini red"><i class="icon-trash"></i> Delete</a></td>
											<td><?php echo $row->datecreated; ?></td>
										</tr>
									<?php } } ?>
									
										
									</tbody>
								</table>
							</div>
						</div>
						<!-- END EXAMPLE TABLE PORTLET-->
					</div>
					</div>
				</div>
				<!-- END VIEW SESSION -->
				<!-- END PAGE CONTENT-->         
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->  
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<?php echo $footer; ?>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<?php echo $js; ?>
	<!-- END PAGE LEVEL PLUGINS -->
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url() . 'assets/scripts/form-components.js'; ?>"></script> 
	<script src="<?php echo base_url().'assets/plugins/data-tables/jquery.dataTables.min.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/plugins/data-tables/DT_bootstrap.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/plugins/data-tables/jquery.dataTables.ReloadAjax.js'; ?>" type="text/javascript"></script> 
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>"></script>
	<script src="<?php echo base_url().'assets/scripts/table-managed.js'; ?>"></script>

	<!-- END PAGE LEVEL SCRIPTS -->
    
	<!-- END PAGE LEVEL SCRIPTS -->

	<script>
		jQuery(document).ready(function() {
		   	// initiate layout and plugins
		   	App.init();
		   	FormComponents.init();
		   	TableManaged.init();
		   	
		   	resetdropdownfields();
		   	//$('.dropdown').select2({ allowClear: true });

			$("#cmdsavestaff").click(function() {
				dovalidationforstaff();
			})

			$("#cmdcancel").click(function() {
				emptyfieldsall();
			})

 			function dovalidationforstaff() {
	        	var form1 = $('#frmstaffdata ');
	            var error1 = $('.alert-error', form1);
	            var success1 = $('.alert-success', form1);

	            form1.validate({
	                errorElement: 'span', //default input error message container
	                errorClass: 'help-inline', // default input error message class
	                focusInvalid: false, // do not focus the last invalid input
	                ignore: "",
	                rules: {
	                    surname: { required: true },
	                	othernames: { required: true },
	                	username: { required: true },
	                	department: { required: true },
	                	gender: { required: true },
	                	password: { required: true },
	                	phonenumber: { required: true, minlength: 11, maxlength: 11,number: 11 },
	                },

	                invalidHandler: function (event, validator) { //display error alert on form submit              
	                    success1.hide();
	                    error1.show();
	                    App.scrollTo(error1, -200);
	                },

	                highlight: function (element) { // hightlight error inputs
	                    $(element)
	                        .closest('.help-inline').removeClass('ok'); // display OK icon
	                    $(element)
	                        .closest('.control-group').removeClass('success').addClass('error'); // set error class to the control group
	                },

	                unhighlight: function (element) { // revert the change done by hightlight
	                    $(element)
	                        .closest('.control-group').removeClass('error'); // set error class to the control group
	                },

	                success: function (label) {
	                    $(label)
	                    .addClass('valid').addClass('help-inline ok') // mark the current input as valid and display OK icon
	                    .closest('.control-group').removeClass('error').addClass('success'); // set success class to the control group
	                },

	                submitHandler: function (form) {
	                    //success1.show();

	                    var imgmsg= '<img  src="<?php echo base_url().'assets/img/spinner.gif';?>">' + 'Saving...';
						$('#msgsave').html(imgmsg);
						$.ajax({
							url: "<?php echo site_url('/adminside/update_staff'); ?>", //redirect to Controllers
							type: "POST",
							data: $("#frmstaffdata").serialize(),
							success: function(data){
								//alert(data);
								$('#msgsave').html('');
								if (data == 1){
									msg="Staff Account Update Successfull";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );							
								}
								else if (data == 2) {
									msg="Account Exist, try another username";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );		
								}
								else{
									msg="Error Saving Information Please try again";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );
								}
							}
				 	 	});
	                }
	            });
	        }

	        function resetdropdownfields() {
	        	$('select').select2({ allowClear: true });
	        }

		});

		


	</script>
	<!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>