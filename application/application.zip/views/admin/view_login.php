<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>JOLUDS  | Admin Login </title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	
	<?php echo $css; ?>

</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="login">
<?php echo $dialogs; ?>
	<!-- BEGIN LOGO -->
	<div class="logo">
		<img src="<?php echo base_url() . 'assets/img/logo.png'; ?>" alt="" width="" height=""/>
	</div>
	<!-- END LOGO -->
	<!-- BEGIN LOGIN -->

	<div class="content">
		
		<!-- BEGIN LOGIN FORM -->
		<form class="form-vertical login-form" id='login-form' action="#">
			<!--<span><i class=" icon-info-sign"></i>Registration Procedure</span><br/>-->
			<!-- <span><center><a data-toggle="modal" href="#reginfodialog" class="btn red"><i class="icon-info-sign m-icon-white">
			</i> Registration Procedure</a></center></span> -->
			
			
			<h3 class="form-title">Login to your account<span id="msg"></span></h3>
			<div class="alert alert-error hide" id='alert-error'>
				<!-- <button class="close" data-dismiss="alert"></button> -->
				<span>Enter your username and password.</span>
			</div>
			<div class="control-group">
				<!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
				<label class="control-label visible-ie8 visible-ie9">Username</label>
				<div class="controls">
					<div class="input-icon left">
						<i class="icon-user"></i>
						<input class="m-wrap placeholder-no-fix user" id="username" type="text" 
						placeholder="Enter Username" name="username"/>
					</div>
				</div>
			</div>
			<div class="control-group">
				<label class="control-label visible-ie8 visible-ie9">Password</label>
				<div class="controls">
					<div class="input-icon left">
						<i class="icon-lock"></i>
						<input class="m-wrap placeholder-no-fix" id="password" type="password" 
						placeholder="Password" name="password"/>
					</div>
				</div>
				<span>
					<small>Forget your password ? &nbsp; 
					<a href="javascript:;" class="forget-password" id="forget-password">Click here</a> to reset it</small>.
				</span>
			</div>
			<div class="form-actions">
				<button type="submit" id="cmdlogin" class="btn blue pull-right">
				Login <i class="m-icon-swapright m-icon-white"></i>
				</button>
			</div>
				<!-- CONFIRMATION LINK -->
			
			
		</form>
		<!-- END LOGIN FORM -->        		
	</div>
	<!-- END LOGIN -->
	<!-- BEGIN COPYRIGHT -->
	<div class="copyright">
		2015 &copy; Powered by QuicKsoft Solutions.
	</div>
	<!-- END COPYRIGHT -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<!-- BEGIN CORE PLUGINS -->
	<?php echo $js; ?>
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="<?php echo base_url() . 'assets/scripts/app.js'; ?>" type="text/javascript"></script>
	<script src="<?php echo base_url() . 'assets/scripts/login.js'; ?>" type="text/javascript"></script>
	<!-- END PAGE LEVEL SCRIPTS --> 
	<script>
		jQuery(document).ready(function() {
		    
		  App.init();
		  // Login.init();

		  	$("#cmdlogin").click(function() {
				$('.login-form').validate({
		            errorElement: 'label', //default input error message container
		            errorClass: 'help-inline', // default input error message class
		            focusInvalid: false, // do not focus the last invalid input
		            rules: {
		                username: {
		                    required: true
		                },
		                password: {
		                    required: true
		                },
		               
		            },

		            messages: {
		                username: {
		                    required: "Username is required."
		                },
		                password: {
		                    required: "Password is required."
		                }
		            },

		            invalidHandler: function (event, validator) { //display error alert on form submit   
		                $('.alert-error', $('.login-form')).show();
		            },

		            highlight: function (element) { // hightlight error inputs
		                $(element)
		                    .closest('.control-group').addClass('error'); // set error class to the control group
		            },

		            success: function (label) {
		                label.closest('.control-group').removeClass('error');
		                label.remove();
		            },

		            errorPlacement: function (error, element) {
		                error.addClass('help-small no-left-padding').insertAfter(element.closest('.input-icon'));
		            },

		            submitHandler: function (form) {
		            	var imgmsg= '<img src="<?php echo base_url().'assets/img/spinner.gif';?>">'+'';
		                $('#msg').html(imgmsg);
		                $.ajax({
							url: "<?php echo site_url('/adminside/validate'); ?>",
							type: "POST",
							data: $("#login-form").serialize(),
							success: function (data) {
								//alert (data);
								$('#msg').html('');
								if (data == 1) {
									window.location.href="<?php echo site_url('adminside/dashboard'); ?>"
								}
								else if (data == 2) 
								{
									msg="Account has been Disabled"
									//alert(msg);
	            					$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );
								}
								else if (data == 3) 
								{
									msg="Wrong username or password, please check your entry and try again."
	            					$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );
								}
								else if (data == 4) {
									msg="User Does not Exist"
									//alert(msg);
	            					$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );

								}
								else if(data == 0){
									msg="Error Login in"
									//alert(msg);
	            					$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );
								}
							}
						});
		            }
		        })
			})
			


			

	        //$("#openreginfodialog").trigger( "click" );

		});


		function isvalid(myvalue){
			var iChars = " !@#$%^&*()+=-_[]\\\';,./{}|\":<>?";
			for (var i = 0; i < myvalue.length; i++) {
			    if (iChars.indexOf(myvalue.charAt(i)) != -1) {
			    	//this.value='';
			        //alert ("Your username has special characters. \nThese are not allowed.\n Please remove them and try again.");
			        return false;
			    }
			}		
		}

		function emptyregistrationfields(){
			$(".reg").val('');
		}
	</script>
	<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>