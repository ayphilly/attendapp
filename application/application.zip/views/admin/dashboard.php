<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>JOLUDS Admin|  Dashboard </title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<?php echo $css; ?>
	<link href="<?php echo base_url().'assets/plugins/gritter/css/jquery.gritter.css" rel="stylesheet'; ?>" type="text/css"/>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="page-header-fixed">
	
	<!-- BEGIN HEADER -->
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="navbar-inner">
			<div class="container-fluid">
				<!-- BEGIN LOGO -->
				<a class="brand" href="#">
				<img src="<?php echo base_url() . 'assets/img/logonew.png'; ?>" alt="logo" />
				</a>
				<!-- END LOGO -->
				<!-- BEGIN RESPONSIVE MENU TOGGLER -->
				<a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
				<img src="<?php echo base_url() . 'assets/img/menu-toggler.png'; ?>" alt="" />
				</a>          
				<!-- END RESPONSIVE MENU TOGGLER -->            
				<!-- BEGIN TOP NAVIGATION MENU -->              
				<ul class="nav pull-right">
					<!-- BEGIN USER LOGIN DROPDOWN -->
					<!-- BEGIN NOTIFICATION DROPDOWN -->   
					<li class="dropdown" id="header_notification_bar">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
						<i class="icon-warning-sign"></i>
						<span class="badge"><?php echo $unreadp; ?></span>
						</a>
						<ul class="dropdown-menu extended notification">
							<li>
								<p>You have <?php echo $unreadp; ?> Unread Paper</p>
							</li>
							<li>
								<ul class="dropdown-menu-list scroller" style="height:150px">
									<?php 
									if(isset($unrpapers)) {
										foreach($unrpapers as $row) {
									?>
										<li>
											<a href="<?php echo base_url() . 'journal/readpaper/'.$row->paid; ?>">
											<span class="label label-warning"><i class="icon-bell"></i></span>
											<?php echo $row->title. ' '.$row->authors; ?>
											<span class="time"><?php echo $row->dateadded; ?></span>
											</a>
										</li>
									<?php } } ?>
								</ul>
							</li>
							<li class="external">
								<a href="<?php echo base_url() . 'journal/papers/'; ?>">Check all Messages <i class="m-icon-swapright"></i></a>
							</li>
						</ul>
					</li>
							<!-- END NOTIFICATION DROPDOWN -->
					<li class="dropdown user">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						Welcome <?php echo $this->session->userdata('fullname'); ?>
						<img alt="" src="<?php echo base_url() . 'uploads/'.$this->session->userdata('image').'.jpg'; ?>" width=29px height=29px />
						<i class="icon-angle-down"></i>
						</a>
						<ul class="dropdown-menu">
						<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'home'; ?>"><i class="icon-home"></i> Website Home</a></li>
							<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'adminside/changepass'; ?>"><i class="icon-lock"></i> Change Password</a></li>
							<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'adminside/signout'; ?>"><i class="icon-key"></i> Log Out</a></li>
						</ul>
					</li>
					<!-- END USER LOGIN DROPDOWN -->
				</ul>
				<!-- END TOP NAVIGATION MENU --> 
			</div>
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container row-fluid">
		<!-- BEGIN SIDEBAR -->
		<?php echo $sidebar; ?>
		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->  
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div id="portlet-config" class="modal hide">
				<div class="modal-header">
					<button data-dismiss="modal" class="close" type="button"></button>
					<h3>portlet Settings</h3>
				</div>
				<div class="modal-body">
					<p>Here will be a configuration form</p>
				</div>
			</div>
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN PAGE CONTAINER-->

			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->   
				<div class="row-fluid">
					<div class="span12">						   
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<h3 class="page-title">
							Dashboard <small>JOLUDS Admin Portal</small>
						</h3>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT-->
				<div id="dashboard">
					<!-- BEGIN DASHBOARD STATS -->
					<div class="row-fluid">
						
							<div class="span3 responsive" data-tablet="span6" data-desktop="span3">
								<div class="dashboard-stat blue">
									<div class="visual">
										<i class="icon-user"></i>
									</div>
									<div class="details">
										<div class="number">
											<?php echo $allstaff; ?>
										</div>
										<div class="desc">                           
											Staff Account
										</div>
									</div>
									<a class="more" href="#">
									View  <i class="m-icon-swapright m-icon-white"></i>
									</a>                 
								</div>
							</div>
							<div class="span3 responsive" data-tablet="span6" data-desktop="span3">
								<div class="dashboard-stat green">
									<div class="visual">
										<i class="icon-home"></i>
									</div>
									<div class="details">
										<div class="number"><?php echo $allppapers; ?></div>
										<div class="desc">Total Published Papers</div>
									</div>
									<a class="more" href="<?php echo site_url('/school/schools'); ?>">
									View<i class="m-icon-swapright m-icon-white"></i>
									</a>                 
								</div>
							</div>
							<div class="span3 responsive" data-tablet="span6  fix-offset" data-desktop="span3">
								<div class="dashboard-stat purple">
									<div class="visual">
										<i class="icon-globe"></i>
									</div>
									<div class="details">
										<div class="number"><?php echo $allvolumes; ?></div>
										<div class="desc">Published Volumes</div>
									</div>
									<a class="more" href="<?php echo site_url('/advert/viewadverts'); ?>">
									View <i class="m-icon-swapright m-icon-white"></i>
									</a>                 
								</div>
							</div>
							<div class="span3 responsive" data-tablet="span6  fix-offset" data-desktop="span3">
								<div class="dashboard-stat red">
									<div class="visual">
										<i class="icon-globe"></i>
									</div>
									<div class="details">
										<div class="number"><?php echo $allsubpapers; ?></div>
										<div class="desc">Submmited Papers</div>
									</div>
									<a class="more" href="<?php echo site_url('/advert/viewvendors'); ?>">
									View <i class="m-icon-swapright m-icon-white"></i>
									</a>                 
								</div>
							</div>
					</div>
					

				</div>
				

				
				<!-- END PAGE CONTENT-->         
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->  
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<?php echo $footer; ?>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<?php echo $js; ?>
	<!-- END PAGE LEVEL PLUGINS -->
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>"></script>
	<script src="<?php echo base_url().'assets/scripts/table-managed.js'; ?>"></script> 

	<script type="text/javascript" src="<?php echo base_url().'assets/plugins/gritter/js/jquery.gritter.js'; ?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/plugins/jquery.pulsate.min.js'; ?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/plugins/jquery.bootpag.min.js'; ?>"></script>

	<!-- END PAGE LEVEL SCRIPTS -->
    
	<!-- END PAGE LEVEL SCRIPTS -->

	<script>
		jQuery(document).ready(function() {
		   	// initiate layout and plugins
		   	App.init();
		   	FormComponents.init();
		   	TableManaged.init();
		   	UIGeneral.init();
		   	
		   	
		   	resetdropdownfields();
		   	//$('.dropdown').select2({ allowClear: true });

			$("#cmdsavestaff").click(function() {
				dovalidationforstaff();
			})

			$("#cmdcancel").click(function() {
				emptyfieldsall();
			})

 			function dovalidationforstaff() {
	        	var form1 = $('#frmstaffdata ');
	            var error1 = $('.alert-error', form1);
	            var success1 = $('.alert-success', form1);

	            form1.validate({
	                errorElement: 'span', //default input error message container
	                errorClass: 'help-inline', // default input error message class
	                focusInvalid: false, // do not focus the last invalid input
	                ignore: "",
	                rules: {
	                    surname: { required: true },
	                	othernames: { required: true },
	                	username: { required: true },
	                	department: { required: true },
	                	gender: { required: true },
	                	password: { required: true },
	                	phonenumber: { required: true, minlength: 11, maxlength: 11,number: 11 },
	                },

	                invalidHandler: function (event, validator) { //display error alert on form submit              
	                    success1.hide();
	                    error1.show();
	                    App.scrollTo(error1, -200);
	                },

	                highlight: function (element) { // hightlight error inputs
	                    $(element)
	                        .closest('.help-inline').removeClass('ok'); // display OK icon
	                    $(element)
	                        .closest('.control-group').removeClass('success').addClass('error'); // set error class to the control group
	                },

	                unhighlight: function (element) { // revert the change done by hightlight
	                    $(element)
	                        .closest('.control-group').removeClass('error'); // set error class to the control group
	                },

	                success: function (label) {
	                    $(label)
	                    .addClass('valid').addClass('help-inline ok') // mark the current input as valid and display OK icon
	                    .closest('.control-group').removeClass('error').addClass('success'); // set success class to the control group
	                },

	                submitHandler: function (form) {
	                    //success1.show();

	                    var imgmsg= '<img  src="<?php echo base_url().'assets/img/spinner.gif';?>">' + 'Saving...';
						$('#msgsave').html(imgmsg);
						$.ajax({
							url: "<?php echo site_url('/adminside/submit_staff'); ?>", //redirect to Controllers
							type: "POST",
							data: $("#frmstaffdata").serialize(),
							success: function(data){
								//alert(data);
								$('#msgsave').html('');
								if (data == 1){
									msg="Staff Account Creation Successfull";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );							
								}
								else if (data == 2) {
									msg="Account Exist, try another username";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );		
								}
								else{
									msg="Error Saving Information Please try again";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );
								}
							}
				 	 	});
	                }
	            });
	        }

	        function resetdropdownfields() {
	        	$('select').select2({ allowClear: true });
	        }

		});

		


	</script>
	<!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>