<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>JOLUDS Admin | Add Volume</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<?php echo $css; ?>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="page-header-fixed">
	<?php echo $dialogs; ?>
	<!-- BEGIN HEADER -->
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="navbar-inner">
			<div class="container-fluid">
				<!-- BEGIN LOGO -->
				<a class="brand" href="#">
				<img src="<?php echo base_url() . 'assets/img/logonew.png'; ?>" alt="logo" />
				</a>
				<!-- END LOGO -->
				<!-- BEGIN RESPONSIVE MENU TOGGLER -->
				<a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
				<img src="<?php echo base_url() . 'assets/img/menu-toggler.png'; ?>" alt="" />
				</a>          
				<!-- END RESPONSIVE MENU TOGGLER -->            
				<!-- BEGIN TOP NAVIGATION MENU -->              
				<ul class="nav pull-right">
					<!-- BEGIN USER LOGIN DROPDOWN -->
					<!-- BEGIN NOTIFICATION DROPDOWN -->   
					<li class="dropdown" id="header_notification_bar">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
						<i class="icon-warning-sign"></i>
						<span class="badge"><?php echo $unreadp; ?></span>
						</a>
						<ul class="dropdown-menu extended notification">
							<li>
								<p>You have <?php echo $unreadp; ?> Unread Paper</p>
							</li>
							<li>
								<ul class="dropdown-menu-list scroller" style="height:150px">
									<?php 
									if(isset($unrpapers)) {
										foreach($unrpapers as $row) {
									?>
										<li>
											<a href="<?php echo base_url() . 'journal/readpaper/'.$row->paid; ?>">
											<span class="label label-warning"><i class="icon-bell"></i></span>
											<?php echo $row->title. ' '.$row->authors; ?>
											<span class="time"><?php echo $row->dateadded; ?></span>
											</a>
										</li>
									<?php } } ?>
								</ul>
							</li>
							<li class="external">
								<a href="<?php echo base_url() . 'journal/papers/'; ?>">Check all Messages <i class="m-icon-swapright"></i></a>
							</li>
						</ul>
					</li>
							<!-- END NOTIFICATION DROPDOWN -->
					<li class="dropdown user">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						Welcome <?php echo $this->session->userdata('fullname'); ?>
						<img alt="" src="<?php echo base_url() . 'uploads/'.$this->session->userdata('image').'.jpg'; ?>" width=29px height=29px />
						<i class="icon-angle-down"></i>
						</a>
						<ul class="dropdown-menu">
						<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'home'; ?>"><i class="icon-home"></i> Website Home</a></li>
							<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'adminside/changepass'; ?>"><i class="icon-lock"></i> Change Password</a></li>
							<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'adminside/signout'; ?>"><i class="icon-key"></i> Log Out</a></li>
						</ul>
					</li>
					<!-- END USER LOGIN DROPDOWN -->
				</ul>
				<!-- END TOP NAVIGATION MENU --> 
			</div>
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container row-fluid">
		<!-- BEGIN SIDEBAR -->
		<?php echo $sidebar; ?>
		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->  
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div id="portlet-config" class="modal hide">
				<div class="modal-header">
					<button data-dismiss="modal" class="close" type="button"></button>
					<h3>portlet Settings</h3>
				</div>
				<div class="modal-body">
					<p>Here will be a configuration form</p>
				</div>
			</div>
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT-->
				<p></p>
				<div class="row-fluid">
					<div class="span12">
						<div class="portlet box grey">
							<div class="portlet-title">
								<div  id="forminfo" class="caption"><i class="icon-reorder"></i> <span> CREATE NEW VOLUME </span> </div>
								
								<div class="tools">
									<a href="javascript:;" class="collapse"></a>
									<a href="javascript:;" class="reload"></a>
								</div>
							</div>

							<div class="portlet-body form">

								<form action="#" id="frmstaffdata" name="frmstaffdata" class="form-horizontal">
									<div class="alert alert-error hide">
										<button class="close" data-dismiss="alert"></button>
										You have some form errors. Please check below.
									</div>
									<div class="alert alert-success hide">
										<button class="close" data-dismiss="alert"></button>
										Your form validation is successful!
									</div>
									<input type="hidden" name="userid" value="<?php echo $this->session->userdata('userid'); ?>"/>
									
									<div class="row-fluid">
										<div class="span4">
											<div class="control-group">
												<label class="control-label">VOLUME<span class="required">*</span></label>
												<div class="controls">
													<input type="text" id="volume" name="volume" class="m-wrap span12 xd" placeholder="JOURNAL VOLUME">
												</div>
											</div>
										</div>
										<!--/span-->
										<div class="span4">
											<div class="control-group">
												<label class="control-label">NUMBER<span class="required">*</span></label>
												<div class="controls">
													<input type="text" value=""  id="volumeno" name="volumeno" class="m-wrap span12 xd" placeholder="VOLUME NUMBER">
												</div>
											</div>
										</div>
										<!--/span-->
										<div class="span4 ">
											<div class="control-group">
												<label class="control-label">VOLUME YEAR</label>
												<div class="controls">
													<input class="span6 m-wrap" id="volumeyear" name="volumeyear" type="text"  />
													<span class="help-inline">2016</span>
												</div>
											</div>
										</div>
										<!--/span-->
									</div>
									<!--/row-->
									
									<div class="form-actions">
										<span id="msgsave" name="msgsave"></span>
										<button type="submit" id="cmdsavevolume" class="btn purple"><i class="icon-ok"></i>ADD VOLUME</button>
										<button type="button" class="btn">CANCEL</button>
									</div>
								</form>
								<!-- PICTURE UPLOAD FORM FOR STUDENTS-->

							</div>
						</div>
					</div>
				</div>
				<!-- BEGIN VIEW SESSION -->
				<div class="row-fluid">
					<div class="span12">
						<div class="span12 responsive" data-tablet="span12 fix-offset" data-desktop="span12">
						<!-- BEGIN EXAMPLE TABLE PORTLET-->
						<div class="portlet box grey">
							<div class="portlet-title">
								<div class="caption"><i class="icon-user"></i>Available Volumes</div>
							</div>
							<div class="portlet-body">
								<table class="table table-striped table-bordered table-hover" id="sample_2">
									<thead>
									
										<tr>
											<th style="width:8px;"><input type="checkbox" class="group-checkable" data-set="#sample_2 .checkboxes" /></th>
											<th>VOLUME</th>
											<th>STATUS</th>
											<th>ADD PAPERS</th>
											<th>ACTION</th>
											<th>Date</th>
										</tr>
									
									</thead>
									<tbody>
									<?php if(isset($vol)) {
										foreach($vol as $row) {
									?>
										<tr class="odd gradeX">
											<td><input type="checkbox" class="checkboxes" value="<?php echo $row->userid; ?>" /></td>
											<td>
												<span class="btn large green-stripe">
												<?php echo 'VOLUME '. $row->volume . ' NUMBER '.$row->volumeno.'  '.$row->volumeyear; ?></span>
											</td>
											<td>
												<?php if ($row->publish==1) { ?>
													<a href="<?php echo base_url() . 'journal/unpvolume/' . $row->vid; ?>" class="btn large blue-stripe">UNPUBLISH</a>
												<?php } 
												elseif ($row->publish == 0) { ?>
												 	<a href="<?php echo base_url() . 'journal/pvolume/' . $row->vid; ?>" class="btn large red-stripe">PUBLISH</a>
												<?php } ?>
											</td>
											<td>
												<?php if ($row->publish == 0) { ?>
													<a href="<?php echo base_url() . 'journal/addpaper/'; ?>" class="btn small purple-stripe">ADD PAPERS</a>
												<?php } ?>
											</td>
											<td>
											<a href="<?php echo base_url() . 'journal/editvolume/' . $row->vid; ?>" class="btn mini blue"><i class="icon-edit"></i> E d i t </a><br />
											<!-- <a href="<?php //echo base_url() . 'journal/deletevolume/' . $row->vid; ?>" class="btn mini red"><i class="icon-trash"></i> Delete</a> --></td>
											<td><?php echo $row->dateadded; ?></td>
										</tr>
									<?php } } ?>
									
										
									</tbody>
								</table>
							</div>
						</div>
						<!-- END EXAMPLE TABLE PORTLET-->
					</div>
					</div>
				</div>
				<!-- END VIEW SESSION -->
				<!-- END PAGE CONTENT-->         
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->  
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<?php echo $footer; ?>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<?php echo $js; ?>
	<!-- END PAGE LEVEL PLUGINS -->
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url() . 'assets/scripts/form-components.js'; ?>"></script> 
	<script src="<?php echo base_url().'assets/plugins/data-tables/jquery.dataTables.min.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/plugins/data-tables/DT_bootstrap.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/plugins/data-tables/jquery.dataTables.ReloadAjax.js'; ?>" type="text/javascript"></script> 
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>"></script>
	<script src="<?php echo base_url().'assets/scripts/table-managed.js'; ?>"></script>

	<!-- END PAGE LEVEL SCRIPTS -->
    
	<!-- END PAGE LEVEL SCRIPTS -->

	<script>
		jQuery(document).ready(function() {
		   	// initiate layout and plugins
		   	App.init();
		   	FormComponents.init();
		   	TableManaged.init();
		   	
		   	resetdropdownfields();
		   	//$('.dropdown').select2({ allowClear: true });

			$("#cmdsavevolume").click(function() {
				dovalidationforvol();
			})

			$("#cmdcancel").click(function() {
				emptyfieldsall();
			})

 			function dovalidationforvol() {
	        	var form1 = $('#frmstaffdata ');
	            var error1 = $('.alert-error', form1);
	            var success1 = $('.alert-success', form1);

	            form1.validate({
	                errorElement: 'span', //default input error message container
	                errorClass: 'help-inline', // default input error message class
	                focusInvalid: false, // do not focus the last invalid input
	                ignore: "",
	                rules: {
	                    volume: { required: true, number: true },
	                	volumeno: { required: true, number: true },
	                	volumeyear: { required: true },
	                },

	                invalidHandler: function (event, validator) { //display error alert on form submit              
	                    success1.hide();
	                    error1.show();
	                    App.scrollTo(error1, -200);
	                },

	                highlight: function (element) { // hightlight error inputs
	                    $(element)
	                        .closest('.help-inline').removeClass('ok'); // display OK icon
	                    $(element)
	                        .closest('.control-group').removeClass('success').addClass('error'); // set error class to the control group
	                },

	                unhighlight: function (element) { // revert the change done by hightlight
	                    $(element)
	                        .closest('.control-group').removeClass('error'); // set error class to the control group
	                },

	                success: function (label) {
	                    $(label)
	                    .addClass('valid').addClass('help-inline ok') // mark the current input as valid and display OK icon
	                    .closest('.control-group').removeClass('error').addClass('success'); // set success class to the control group
	                },

	                submitHandler: function (form) {
	                    //success1.show();

	                    var imgmsg= '<img  src="<?php echo base_url().'assets/img/spinner.gif';?>">' + 'Saving...';
						$('#msgsave').html(imgmsg);
						$.ajax({
							url: "<?php echo site_url('/journal/submit_volume'); ?>", //redirect to Controllers
							type: "POST",
							data: $("#frmstaffdata").serialize(),
							success: function(data){
								//alert(data);
								$('#msgsave').html('');
								if (data == 1){
									msg="Volume Created";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );							
								}
								else if (data == 2) {
									msg="Volume Exist";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );		
								}
								else{
									msg="Error Saving Information Please try again";
									//alert(msg);
									$("#anymsg").html(msg);
									$("#openanydialog").trigger( "click" );
								}
							}
				 	 	});
	                }
	            });
	        }

	        function resetdropdownfields() {
	        	$('select').select2({ allowClear: true });
	        }

		});

		


	</script>
	<!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>