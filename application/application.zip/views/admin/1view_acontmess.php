<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<title>JOLUDS Admin | Contact Messages</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<?php echo $css; ?>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="page-header-fixed">
	<?php echo $dialogs; ?>
	<!-- BEGIN HEADER -->
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="navbar-inner">
			<div class="container-fluid">
				<!-- BEGIN LOGO -->
				<a class="brand" href="#">
				<img src="<?php echo base_url() . 'assets/img/logonew.png'; ?>" alt="logo" />
				</a>
				<!-- END LOGO -->
				<!-- BEGIN RESPONSIVE MENU TOGGLER -->
				<a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
				<img src="<?php echo base_url() . 'assets/img/menu-toggler.png'; ?>" alt="" />
				</a>          
				<!-- END RESPONSIVE MENU TOGGLER -->            
				<!-- BEGIN TOP NAVIGATION MENU -->              
				<ul class="nav pull-right">
					<!-- BEGIN USER LOGIN DROPDOWN -->
					<!-- BEGIN NOTIFICATION DROPDOWN -->   
					<li class="dropdown" id="header_notification_bar">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
						<i class="icon-warning-sign"></i>
						<span class="badge"><?php echo $unreadp; ?></span>
						</a>
						<ul class="dropdown-menu extended notification">
							<li>
								<p>You have <?php echo $unreadp; ?> Unread Paper</p>
							</li>
							<li>
								<ul class="dropdown-menu-list scroller" style="height:150px">
									<?php 
									if(isset($unrpapers)) {
										foreach($unrpapers as $row) {
									?>
										<li>
											<a href="<?php echo base_url() . 'journal/readpaper/'.$row->paid; ?>">
											<span class="label label-warning"><i class="icon-bell"></i></span>
											<?php echo $row->title. ' '.$row->authors; ?>
											<span class="time"><?php echo $row->dateadded; ?></span>
											</a>
										</li>
									<?php } } ?>
								</ul>
							</li>
							<li class="external">
								<a href="<?php echo base_url() . 'journal/papers/'; ?>">Check all Messages <i class="m-icon-swapright"></i></a>
							</li>
						</ul>
					</li>
							<!-- END NOTIFICATION DROPDOWN -->
					<li class="dropdown user">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						Welcome <?php echo $this->session->userdata('fullname'); ?>
						<img alt="" src="<?php echo base_url() . 'uploads/'.$this->session->userdata('image').'.jpg'; ?>" width=29px height=29px />
						<i class="icon-angle-down"></i>
						</a>
						<ul class="dropdown-menu">
						<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'home'; ?>"><i class="icon-home"></i> Website Home</a></li>
							<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'adminside/changepass'; ?>"><i class="icon-lock"></i> Change Password</a></li>
							<li class="divider"></li>
							<li><a href="<?php echo base_url() . 'adminside/signout'; ?>"><i class="icon-key"></i> Log Out</a></li>
						</ul>
					</li>
					<!-- END USER LOGIN DROPDOWN -->
				</ul>
				<!-- END TOP NAVIGATION MENU --> 
			</div>
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container row-fluid">
		<!-- BEGIN SIDEBAR -->
		<?php echo $sidebar; ?>
		<!-- END SIDEBAR -->
		<!-- BEGIN PAGE -->  
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div id="portlet-config" class="modal hide">
				<div class="modal-header">
					<button data-dismiss="modal" class="close" type="button"></button>
					<h3>portlet Settings</h3>
				</div>
				<div class="modal-body">
					<p>Here will be a configuration form</p>
				</div>
			</div>
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN PAGE CONTAINER-->
			<div class="container-fluid">
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT-->
				
				<div class="row-fluid">
					<div class="span12 news-page blog-page">
						<div class="row-fluid">
							<div class="span8 blog-tag-data">
								<h1>Read Contact Message</h1>
								<div class="row-fluid">
									<div class="span6">
										<ul class="unstyled inline blog-tags">
											<li>
												<i class="icon-tags"></i> 
												<a href="#"><?php if(isset($amessage)) echo $amessage->subject; ?></a> 
												
											</li>
										</ul>
									</div>
									<div class="span6 blog-tag-data-inner">
										<ul class="unstyled inline">
											<li><i class="icon-user"></i> <a href="#"><?php if(isset($amessage)) echo $amessage->fullname; ?></a></li>
											<li><i class="icon-mail"></i> <a href="#"><?php if(isset($amessage)) echo $amessage->emailaddress; ?></a></li>
										</ul>
									</div>
								</div>
								<div class="news-item-page">
									<blockquote class="hero">
										<strong>Message</strong>
										<p><?php if(isset($amessage)) echo $amessage->message; ?></p>
										<small>Date:- <?php if(isset($amessage)) echo $amessage->datesent; ?> </small>
										
									</blockquote>
									
								</div>
								<hr>
								
								
							</div>
							
						</div>
					</div>
				</div>
				<!-- END VIEW SCHOOL -->
				<div class="row-fluid">
					<div class="span12">
						<div class="span12 responsive" data-tablet="span12 fix-offset" data-desktop="span12">
						<!-- BEGIN EXAMPLE TABLE PORTLET-->
						<div class="portlet box grey">
							<div class="portlet-title">
								<div class="caption"><i class="icon-user"></i>Contact Messages</div>
								
								<div class="actions">
									<a href="#" class="btn blue"><i class="icon-pencil"></i> </a>
									<div class="btn-group">
										<a class="btn green" href="#" data-toggle="dropdown">
										<i class="icon-cogs"></i> Tools
										<i class="icon-angle-down"></i>
										</a>
										<ul class="dropdown-menu pull-right">
											<li><a href="#"><i class="icon-trash"></i> </a></li>
											<li class="divider"></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="portlet-body">
								<table class="table table-striped table-bordered table-hover" id="sample_2">
									<thead>
									
										<tr>
											<th style="width:8px;"><input type="checkbox" class="group-checkable" data-set="#sample_2 .checkboxes" /></th>
											<th>FULLNAME</th>
											<th>EMAIL</th>
											<th>PHONE</th>
											<th>ACTION</th>
											<th>DATE</th>
										</tr>
									
									</thead>
									<tbody>
									<?php if(isset($message)) {
										foreach($message as $row) {
									?>
										<tr class="odd gradeX">
											<td><input type="checkbox" class="checkboxes" value="<?php echo $row->comid; ?>" /></td>
											<td><?php echo $row->fullname; ?></td>
											<td><?php echo $row->emailaddress; ?></td>
											<td><?php echo $row->phonenumber; ?></td>
											<td>
											<a href="<?php echo base_url() . 'adminside/readconmess/'. $row->comid; ?>" 
											class="btn large blue"><i class="icon-envelope"></i> READ</a></td>
											<td><?php echo $row->timestamp; ?></td>
										</tr>
									<?php } } ?>
									</tbody>
								</table>
							</div>
						</div>
						<!-- END EXAMPLE TABLE PORTLET-->
					</div>
					</div>
				</div>
				<!-- END PAGE CONTENT-->         
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->  
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
	<?php echo $footer; ?>
	<!-- END FOOTER -->
	<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
	<?php echo $js; ?>
	<!-- END PAGE LEVEL PLUGINS -->
	<!-- BEGIN PAGE LEVEL SCRIPTS -->
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url() . 'assets/scripts/form-components.js'; ?>"></script> 
	<script src="<?php echo base_url().'assets/plugins/data-tables/jquery.dataTables.min.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/plugins/data-tables/DT_bootstrap.js'; ?>" type="text/javascript"></script>  
	<script src="<?php echo base_url().'assets/plugins/data-tables/jquery.dataTables.ReloadAjax.js'; ?>" type="text/javascript"></script> 
	<script src="<?php echo base_url().'assets/scripts/app.js'; ?>"></script>
	<script src="<?php echo base_url().'assets/scripts/table-managed.js'; ?>"></script>

	<!-- END PAGE LEVEL SCRIPTS -->
    
	<!-- END PAGE LEVEL SCRIPTS -->

	<script>
		
		jQuery(document).ready(function() {
		   	// initiate layout and plugins
		   	App.init();
		   	TableManaged.init();
		   	
		   	$(".qqqqq").click(function() {
                    var checkValues = $('input[name="schools[]"]:checked').map(function(){
                    return $(this).val();}).get();
                    //alert(checkValues);
                    extrastrings="&ids="+checkValues;
                    $.ajax({
                        url: "<?php echo site_url('home/compareschools'); ?>",
                        type: "POST",
                        data: $("#frmcompareschool").serialize()+extrastrings,
                        success: function (data) {
                            //alert (data);
                            $('#msg').html('');
                            if (data != 1) {
                                //return false;
                                window.location.href="<?php echo site_url('home/compare'); ?>"
                            }
                        }
                    });


                })

		});

		


	</script>
	<!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>