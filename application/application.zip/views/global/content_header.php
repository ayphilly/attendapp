<div class="row-fluid">
	<div class="span12">
		  
		<h3 class="page-title">
			Student's Data Form
			 <small>Form about student information</small>
		</h3>
		<ul class="breadcrumb">
			<li>
				<i class="icon-home"></i>
				<a href="#">Home</a> 
				<span class="icon-angle-right"></span>
			</li>
			<li>
				<a href="#">Student's Form</a>
				<span class="icon-angle-right"></span>
			</li>
			<li><a href="#">Data Form</a></li>
		</ul>
	</div>
</div>