<div class="page-sidebar nav-collapse collapse">
	<!-- BEGIN SIDEBAR MENU -->        
	<ul class="page-sidebar-menu">
		<li>
			<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
			<div class="sidebar-toggler hidden-phone"></div>
			<!-- BEGIN SIDEBAR TOGGLER BUTTON -->
		</li>
		
			
			<?php $userid = $this->session->userdata('rightlevel');
        	if($userid == 1 or $userid == 2) {?>
			<li >
				<a href="<?php echo site_url('/adminside/dashboard'); ?>">
				<i class="icon-home"></i> 
				<span class="title">Dashboard</span>
				</a>
			</li>
			<li >
				<a href="<?php echo site_url('/adminside/staff'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Admin Manager</span>
				</a>
			</li>	
			<li >
				<a href="<?php echo site_url('/journal/users'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Registered Users</span>
				</a>
			</li>	
			
			<li >
				<a href="<?php echo site_url('/journal/volume'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Journal Volumes</span>
				</a>
			</li>
			<li >
				<a href="<?php echo site_url('/journal/subpapers'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Submmited Papers</span>
				</a>
			</li>
			<li >
				<a href="<?php echo site_url('/journal/addpaper'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Published Papers</span>
				</a>
			</li>
			<li >
				<a href="<?php echo site_url('/journal/addfeatured'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Featured Papers</span>
				</a>
			</li>
			<li >
				<a href="<?php echo site_url('/journal/messages'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Author Messages</span>
				</a>
			</li>
			<li >
				<a href="<?php echo site_url('/adminside/contactmessages'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Contact Messages</span>
				</a>
			</li>


			
			<!--<li >
				<a href="<?php echo site_url('/adminside/viewnewletter'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Newletter Subscribers</span>
				</a>
			</li>
			 <li >
				<a href="<?php echo site_url('/journal/pages'); ?>">
				<i class="icon-table"></i> 
				<span class="title">Pages</span>
				</a>
			</li> -->
			
		<?php } ?>
		
		
		
		
	</ul>
	<!-- END SIDEBAR MENU -->
</div>