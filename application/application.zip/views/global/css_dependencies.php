<!-- BEGIN GLOBAL MANDATORY STYLES -->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/plugins/bootstrap/css/bootstrap.min.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/plugins/bootstrap/css/bootstrap-responsive.min.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/plugins/font-awesome/css/font-awesome.min.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/style-metro.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/style.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/style-responsive.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/themes/default.css'; ?>" type="text/css" id="style_color"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/plugins/uniform/css/uniform.default.css'; ?>" type="text/css"/>
	<!-- END GLOBAL MANDATORY STYLES -->
	
	<!-- BEGIN PAGE LEVEL STYLES -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-datetimepicker/css/datetimepicker.css'; ?>" />
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/pages/login.css'; ?>" type="text/css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/select2/select2_metro.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/chosen-bootstrap/chosen/chosen.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/data-tables/DT_bootstrap.css'; ?>" />
	<!-- END PAGE LEVEL STYLES -->

	<!-- BEGIN PAGE LEVEL STYLES -->
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/pages/invoice.css'; ?>" type="text/css"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/print.css'; ?>" type="text/css" media="print"/>
	<link rel="stylesheet" href="<?php echo base_url() . 'assets/css/print.css'; ?>" type="text/css" media="print"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.css'; ?>"/>
	<link href="<?php echo base_url() . 'assets/plugins/bootstrap-modal/css/bootstrap-modal.css'; ?>" rel="stylesheet" type="text/css"/>
	<link href="<?php echo base_url() . 'assets/plugins/gritter/css/jquery.gritter.css" rel="stylesheet'; ?>" type="text/css"/>
	<link href="<?php echo base_url() . 'assets/plugins/bootstrap-fileupload/bootstrap-fileupload.css'; ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url() . 'assets/css/pages/profile.css'; ?>" rel="stylesheet" type="text/css" />
	<!-- END PAGE LEVEL STYLES -->

	<!-- FOR DATE PICKER -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/jquery-ui.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/jquery-tags-input/jquery.tagsinput.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/clockface/css/clockface.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-datepicker/css/datepicker.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-timepicker/compiled/timepicker.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-colorpicker/css/colorpicker.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-toggle-buttons/static/stylesheets/bootstrap-toggle-buttons.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-daterangepicker/daterangepicker.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-datetimepicker/css/datetimepicker.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/jquery-multi-select/css/multi-select-metro.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/bootstrap-modal/css/bootstrap-modal.css'; ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.css'; ?>"/>

	<link rel="shortcut icon" href="<?php echo base_url() . 'favicon.ico'; ?>" />