

<script src="<?php echo base_url() . 'assetsp/js/jquery.js'; ?>"></script> 
<script src="<?php echo base_url() . 'assetsp/js/bootstrap.min.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/jquery.fancybox.pack.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/jquery.fancybox-media.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/owl.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/mixitup.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/validate.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/wow.js'; ?>"></script>
<script src="<?php echo base_url() . 'assetsp/js/script.js'; ?>"></script>