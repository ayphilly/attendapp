<div class="navbar-inner">
	<div class="container-fluid">
		<!-- BEGIN LOGO -->
		<a class="brand" href="#">
		<img src="<?php echo base_url() . 'assets/img/logonew.png'; ?>" alt="logo" />
		</a>
		<!-- END LOGO -->
		<!-- BEGIN RESPONSIVE MENU TOGGLER -->
		<a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
		<img src="<?php echo base_url() . 'assets/img/menu-toggler.png'; ?>" alt="" />
		</a>          
		<!-- END RESPONSIVE MENU TOGGLER -->            
		<!-- BEGIN TOP NAVIGATION MENU -->              
		<ul class="nav pull-right">
			<!-- BEGIN USER LOGIN DROPDOWN -->
			<!-- BEGIN NOTIFICATION DROPDOWN -->   
			<li class="dropdown" id="header_notification_bar">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
				<i class="icon-warning-sign"></i>
				<span class="badge">6</span>
				</a>
				<ul class="dropdown-menu extended notification">
					<li>
						<p>You have 6 New Messages</p>
					</li>
					<li>
						<ul class="dropdown-menu-list scroller" style="height:150px">
							
							<li>
								<a href="#">
								<span class="label label-warning"><i class="icon-bell"></i></span>
								Server #2 not responding.
								<span class="time">22 mins</span>
								</a>
							</li>
							
						</ul>
					</li>
					<li class="external">
						<a href="#">Check all Messages <i class="m-icon-swapright"></i></a>
					</li>
				</ul>
			</li>
			<!-- END NOTIFICATION DROPDOWN -->
			<li class="dropdown user">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
				Welcome <?php echo $this->session->userdata('fullname'); ?>
				<img alt="" src="<?php echo base_url() . 'uploads/'.$this->session->userdata('image').'.jpg'; ?>" width=29px height=29px />
				<i class="icon-angle-down"></i>
				</a>
				<ul class="dropdown-menu">
				<li class="divider"></li>
					<li><a href="<?php echo base_url() . 'home'; ?>"><i class="icon-home"></i> Website Home</a></li>
					<li class="divider"></li>
					<li><a href="<?php echo base_url() . 'adminside/changepass'; ?>"><i class="icon-lock"></i> Change Password</a></li>
					<li class="divider"></li>
					<li><a href="<?php echo base_url() . 'adminside/signout'; ?>"><i class="icon-key"></i> Log Out</a></li>
				</ul>
			</li>
			<!-- END USER LOGIN DROPDOWN -->
		</ul>
		<!-- END TOP NAVIGATION MENU --> 
	</div>
</div>