<!-- Main Header-->
    <header class="main-header">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container clearfix">
                <!--Top Left-->
                <div class="top-left pull-left">
                    <ul class="links-nav clearfix">
                        <li><a href="#"><span class="fa fa-phone"></span> Call Us : +(234) 802 1378 866</a></li>
                        <li><a href="#"><span class="fa fa-envelope-o"></span> Email Us : Support@joluds.com</a></li>
                    </ul>
                </div>
                
                <!--Top Right-->
                <div class="top-right pull-right">
                    <div class="social-links clearfix">
                        <a href="#"><span class="fa fa-facebook-f"></span></a>
                        <a href="#"><span class="fa fa-google-plus"></span></a>
                        <a href="#"><span class="fa fa-twitter"></span></a>
                        <a href="#"><span class="fa fa-linkedin"></span></a>
                    </div>
                </div>
            </div>
        </div><!-- Header Top End -->
        
        <!--Header-Upper-->
        <div class="header-upper">
            <div class="auto-container">
                <div class="clearfix">
                    
                    <div class="pull-left logo-outer">
                        <div class="logo"><a href="index.html"><img src="<?php echo base_url() . 'assetsp/images/logo.png'; ?>" alt="Baltimore" title="Baltimore"></a></div>
                    </div>
                    
                    <div class="pull-right upper-right clearfix">
                        
                        <!--Info Box-->
                        <div class="upper-column info-box">
                            <div class="icon-box"><span class="flaticon-location"></span></div>
                            <ul>
                                <li><a href="#"><span class="fa fa-phone"></span> Call Us : +(234) 802 1378 866</a></li>
                                <li><a href="#"><span class="fa fa-envelope-o"></span> Email Us : Support@joluds.com</a></li>
                            </ul>
                        </div>
                        
                        <!--Info Box-->
                        <div class="upper-column info-box">
                            <div class="link-btn">
                                <a href="<?php echo site_url('/home/login'); ?>" class="theme-btn btn-style-one">Login</a>
                            </div>
                        </div>
                        
                        <!--Info Box-->
                        <div class="upper-column info-box">
                            <div class="link-btn">
                                <a href="<?php echo site_url('/home/register'); ?>" class="theme-btn btn-style-one">Register</a>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
        
        <!--Header-Lower-->
        <div class="header-lower">
            
            <div class="auto-container">
                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->      
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="<?php echo site_url('/home'); ?>">Home</a> </li>
                                <li class=""><a href="<?php echo site_url('/home/about'); ?>">About Us</a></li>
                                <li class=""><a href="<?php echo site_url('/home/publications'); ?>">Publications</a></li>
                                <li class=""><a href="<?php echo site_url('/home/instruction'); ?>">Instruction</a></li>
                                <li class=""><a href="<?php echo site_url('/home/editors'); ?>">Editorial Board</a></li>
                                <li class=""><a href="<?php echo site_url('/home/contact'); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                    
                </div>
            </div>
        </div>
        
        
        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.html" class="img-responsive"><img src="<?php echo base_url() . 'assetsp/images/logo-small.png'; ?>" alt="Transpo" title="Transpo"></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->      
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="<?php echo site_url('/home'); ?>">Home</a> </li>
                                <li class=""><a href="<?php echo site_url('/home/about'); ?>">About Us</a></li>
                                <li class=""><a href="<?php echo site_url('/home/publications'); ?>">Publications</a></li>
                                <li class=""><a href="<?php echo site_url('/home/instruction'); ?>">Instruction</a></li>
                                <li class=""><a href="<?php echo site_url('/home/editors'); ?>">Editorial Board</a></li>
                                <li class=""><a href="<?php echo site_url('/home/contact'); ?>">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
                
            </div>
        </div><!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->