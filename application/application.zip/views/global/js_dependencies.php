<script src="<?php echo base_url() . 'assets/plugins/jquery-1.10.1.min.js'; ?>" type="text/javascript"></script>
<script src="<?php echo base_url() . 'assets/plugins/jquery-migrate-1.2.1.min.js'; ?>" type="text/javascript"></script>
<!-- IMPORTANT! Load jquery-ui-1.10.1.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<script src="<?php echo base_url() . 'assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js'; ?>" type="text/javascript"></script>      
<script src="<?php echo base_url() . 'assets/plugins/bootstrap/js/bootstrap.min.js'; ?>" type="text/javascript"></script>
<!--[if lt IE 9]>
<script src="assets/plugins/excanvas.min.js"></script>
<script src="ssets/plugins/respond.min.js"></script>  
<![endif]-->   
<script src="<?php echo base_url() . 'assets/plugins/jquery-slimscroll/jquery.slimscroll.min.js'; ?>" type="text/javascript"></script>
<script src="<?php echo base_url() . 'assets/plugins/jquery.blockui.min.js'; ?>" type="text/javascript"></script>  
<script src="<?php echo base_url() . 'assets/plugins/jquery.cookie.min.js'; ?>" type="text/javascript"></script>
<script src="<?php echo base_url() . 'assets/plugins/uniform/jquery.uniform.min.js'; ?>" type="text/javascript" ></script>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<script src="<?php echo base_url() . 'assets/plugins/jquery-validation/dist/jquery.validate.min.js'; ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/jquery-validation/dist/additional-methods.min.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/select2/select2.min.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/chosen-bootstrap/chosen/chosen.jquery.min.js'; ?>"></script>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL STYLES -->
<script src="<?php echo base_url() . 'assets/scripts/app.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/scripts/form-validation.js'; ?>"></script> 
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js'; ?>"></script>
<script src="<?php echo base_url() . 'assets/scripts/form-components.js'; ?>"></script> 
<!-- END PAGE LEVEL STYLES -->    

<!-- FOR DATE PICKER -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/jquery-1.9.1.js'; ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/jquery-ui.js'; ?>" />


<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/ckeditor/ckeditor.js'; ?>"></script>  
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-fileupload/bootstrap-fileupload.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/chosen-bootstrap/chosen/chosen.jquery.min.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/select2/select2.min.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js'; ?>"></script> 
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/jquery-tags-input/jquery.tagsinput.min.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-toggle-buttons/static/js/jquery.toggle.buttons.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/clockface/js/clockface.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-daterangepicker/date.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-daterangepicker/daterangepicker.js'; ?>"></script> 
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js'; ?>"></script>  
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/bootstrap-timepicker/js/bootstrap-timepicker.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/jquery-inputmask/jquery.inputmask.bundle.min.js'; ?>"></script>   
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/jquery.input-ip-address-control-1.0.min.js'; ?>"></script>
<script type="text/javascript" src="<?php echo base_url() . 'assets/plugins/jquery-multi-select/js/jquery.multi-select.js'; ?>"></script>   
<script src="<?php echo base_url() . 'assets/plugins/bootstrap-modal/js/bootstrap-modal.js'; ?>" type="text/javascript" ></script>
<script src="<?php echo base_url() . 'assets/plugins/bootstrap-modal/js/bootstrap-modalmanager.js'; ?>" type="text/javascript" ></script> 
<script src="<?php echo base_url() . 'assets/scripts/form-components.js'; ?>"></script> 
<script src="<?php echo base_url() . 'assets/scripts/ui-modals.js'; ?>"></script>    