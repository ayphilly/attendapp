<div class="footer">
	<div class="footer-inner">
		2015 &copy; Powered by QuicKsoft Solutions.
	</div>
	<div class="footer-tools">
		<span class="go-top">
		<i class="icon-angle-up"></i>
		</span>
	</div>
</div>