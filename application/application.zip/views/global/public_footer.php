 <!--Main Footer-->
    <footer class="main-footer">
        <div class="auto-container">
        
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row clearfix">
                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget about-widget">
                                    <!--Logo-->
                                    <div class="footer-logo"><a href="index.html"><img src="<?php echo base_url() . 'assetsp/images/logo-2.png'; ?>" alt=""></a></div>
                                    
                                    <div class="widget-content">
                                        <div class="text">The The Journal of Land Use and Development Studies is the number one academic and professional delight in the field of real Natural and Built Environmental Studies. The Journal was floated by the Property Research Group in 2005 and has since published many editions to date with quality papers from professionals and academics in the industry.</div>
                                        
                                        <div class="social-links">
                                            <a href="#"><span class="fa fa-facebook-f"></span></a>
                                            <a href="#"><span class="fa fa-twitter"></span></a>
                                            <a href="#"><span class="fa fa-linkedin"></span></a>
                                            <a href="#"><span class="fa fa-linkedin"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-6 col-sm-6 col-xs-12">
                                <div class="footer-widget links-widget">
                                    <h2>Pages</h2>
                                    <div class="widget-content">
                                        <ul class="list">
                                            <li class="current"><a href="<?php echo site_url('/home'); ?>">Home</a> </li>
                                            <li class=""><a href="<?php echo site_url('/home/about'); ?>">About Us</a></li>
                                            <li class=""><a href="<?php echo site_url('/home/publications'); ?>">Publications</a></li>
                                            <li class=""><a href="<?php echo site_url('/home/instruction'); ?>">Instruction</a></li>
                                            <li class=""><a href="<?php echo site_url('/home/editors'); ?>">Editorial Board</a></li>
                                            <li class=""><a href="<?php echo site_url('/home/contact'); ?>">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-md-6 col-sm-12 col-xs-12">
                        <div class="row clearfix">
                            
                           <!--Footer Column-->
                            <div class="footer-column col-md-8 col-sm-6 col-xs-12">
                                <div class="footer-widget links-widget">
                                    <strong>We interested in publishing a broad spectrum of papers on issues relating to the following areas:</strong>
                                    <div class="widget-content">
                                        <ul class="list">
                                           <li><a href="#">-Property Valuation and Project Management</a></li>
                                            <li><a href="#">-Architecture and Planning</a></li>
                                            <li><a href="#">-Property and Facility Management</a></li>
                                            <li><a href="#">-Land Resources Conservation and Management</a></li>
                                            <li><a href="#">-Construction Economics and Quantity Surveying</a></li>

                                            <li><a href="#">-Property Investment and Property Finance</a></li>
                                            <li><a href="#">-Information Technology</a></li>
                                            <li><a href="#">-Property Rating and Taxation</a></li>
                                            <li><a href="#">-Property Law</a></li>
                                            <li><a href="#">-Construction Technology and Management</a></li>
                                            <li><a href="#">-Housing</a></li>
                                            <li><a href="#">-Rural Land Use, Agriculture and Uban Forestry</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-md-4 col-sm-6 col-xs-12">
                                <div class="footer-widget contact-widget">
                                    <h2>Contact us</h2>
                                    <div class="widget-content">
                                        <ul class="contact-info">
                                            <li><h4><span class="icon flaticon-envelope-1"></span> Email us</h4><div class="text">info@joluds.com <br>support@joluds.com</div></li>
                                            <li><h4><span class="icon flaticon-telephone-1"></span> Call Us</h4><div class="text">+(234) 802 1378 866<br></div></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                 </div>
            </div>
         
        </div>
        
        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-5 col-md-12 col-xs-12"><div class="copyright-text">&copy; 2016 All Rights Reserved</div></div>
                    <div class="col-lg-7 col-md-12 col-xs-12">
                        <!--Bottom Nav-->
                        <nav class="footer-nav clearfix">
                            <ul class="pull-right clearfix">
                                <li><a href="#">Designed By:QuicKsoft Solutions</a></li>
                               
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            
        </div>
         
    </footer>
    